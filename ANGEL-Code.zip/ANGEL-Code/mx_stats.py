
#!/usr/bin/env python3
# -*- coding: utf-8 -*-


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
author: Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

auxiliary methods to plot statistics on a benchmark of multiplexes
'''

import numpy as np
import networkx as nx
import collections
import random
import collections as coll
import statistics as stats
import matplotlib.pyplot as plt

import mx_functions as mf


"""
IMPORTANT
number of nodes the multiplex must have to compare with other models
"""
MX_NODE_CNT = 0
def setNfOfNode(nb):
    global MX_NODE_CNT
    MX_NODE_CNT = nb
    print('Nb of nodes', MX_NODE_CNT)
    
   
"""
set colors in boxplots
"""
def set_box_color(bp, c1='black', c2 = 'black', c3='black', c4='black'):
    plt.setp(bp['boxes'], color=c1)
    plt.setp(bp['whiskers'], color=c2)
    plt.setp(bp['caps'], color=c3)
    plt.setp(bp['medians'], color=c4)
    plt.setp(bp['fliers'], markeredgecolor=c1, marker='+')


"""
KS-TEST

@param:
    list - list with sample to test its distr.
    dict - cumulative histogram values 

"""
def ks_test(sample):
    my_dict = {i:sample.count(i) for i in sample}
    my_dict = dict(sorted(my_dict.items()))
    s = sum(np.array(list(my_dict.values())))
    p_dict = {}
    for i in range(max(list(my_dict.keys()))+1) :
        p_dict[i] = 0
        for k, v in my_dict.items():
            if k >= i:
                p_dict[i] += v
    n_dict = {}
    for k in my_dict.keys():
        n_dict[k] = p_dict[k]/s
    
    return n_dict
 
"""       
create a multiplex layers
@param:
    list of layers - graph objects - with nodes as subset of a common node set
@return:
    muliplex - a multigraph object on edge sets layers in the list
"""
def create_multiplex(LAYERS):
    MX = nx.MultiGraph()
    for L in LAYERS: MX.add_edges_from(L.edges)
    if MX.number_of_nodes() < MX_NODE_CNT:
        for no in range(MX_NODE_CNT):
            if no not in MX.nodes:
                MX.add_node(no)
    return MX

"""
compute layer repetition count per node
@param:
    node
    list of layers
@return:
    layer repetition count for node
"""
def layer_repetition_count(node, LAYERS) :
    count = 0
    for L in LAYERS :
        if L.has_node(node) :
            count += 1
    return count

"""
sort layers by node size
"""
def sort_layers_by_nodesize(LAYERS, reverse=False):
    d = {k: LAYERS[k].number_of_nodes() for k in range(len(LAYERS))}
    d_ord = collections.OrderedDict(sorted(d.items(), key=lambda t: t[1], reverse=reverse))
    N = []
    for k, _ in d_ord.items():
        N.append(LAYERS[k]) 
    return N   

"""
sort layers by s-metric
"""
def sort_layers_by_smetric(LAYERS, reverse=False):
    sm = []
    for L in LAYERS:
        m = L.number_of_edges()
        sm.append(round(nx.smetric.s_metric(L, normalized=False)/(m*m),2))
    d = dict(zip(range(len(LAYERS)), sm))
    d_ord = collections.OrderedDict(sorted(d.items(), key=lambda t: t[1], reverse=reverse))
    
    return [LAYERS[k] for k, _ in d_ord.items()], [v for _, v in d_ord.items()]
                   
    
    
"""
sort boxplots with synthetic data by median, 
sort data (list of lists) by median 
and save the ordering for the reference
@param: 
    data - list of lists
    index - list to be sorted in median data order
"""
  
def sort_by_median(data, order):
    length = len(data)
    for _ in range(length):
        for j in range(length - 1):
            if stats.median(data[j]) > stats.median(data[j+1]) :
                temp = data[j]
                data[j] = data[j+1]
                data[j+1] = temp
                
                val = order[j]
                order[j] = order[j+1]
                order[j+1] = val
            elif stats.median(data[j]) == stats.median(data[j+1]) and stats.mean(data[j]) > stats.mean(data[j+1]) :
                temp = data[j]
                data[j] = data[j+1]
                data[j+1] = temp
                
                val = order[j]
                order[j] = order[j+1]
                order[j+1] = val
           
"""
sort boxplots with synthetic data by median, 
the last entry is multiplex, leave it at the end as it is 
@param: 
    data - list of lists
"""
# sort boxplots by median, 
def sort_by_median0(data):
    length = len(data)
    for _ in range(length-1):
        for j in range(length - 2):
            if stats.median(data[j]) > stats.median(data[j+1]) :
                temp = data[j]
                data[j] = data[j+1]
                data[j+1] = temp

"""
sort data by ref_list, sort data (list of lists) by median 
and saves the ordering
@param: 
    data - list of lists
    index - list to be sorted in data order
"""
def sort_by_ref(data, ref):
    length = len(data)
    for _ in range(length):
        for j in range(length - 1):
            if ref[j] > ref[j+1] :
                temp = data[j]
                data[j] = data[j+1]
                data[j+1] = temp
                
                temp = ref[j]
                ref[j] = ref[j+1]
                ref[j+1] = temp
                
"""
compute standard deviation synthetic data versus reference
"""
def comp_std(syn_data, ref_data):
    stds = []
    for i in range(len(ref_data)):
        std = 0
        for val in syn_data[i]:
            std += (ref_data[i] - val) * (ref_data[i] - val)
        stds.append(std/(len(ref_data) -1))
    return stds

"""
chi-quadrat test
"""            
def chi_quadrat(ref_list, syn_lists):
    all_syn_vals = []
    for vals in syn_lists: all_syn_vals.extend(vals)
    cnt_ref = collections.Counter(ref_list)
    cnt_syn = collections.Counter(all_syn_vals)
    m = len(ref_list)
    chi = 0
    for k, v in cnt_ref.items():
        nj = cnt_syn[k]/m  # statt *100 /100
        chi += (v - nj) * (v - nj)/ nj
    return chi
    
"""
**************************************************************************
**************************************************************************

STATISTICS TO COMPARE SINGLE LAYER REPLICATION

per layer of a real network -> nbOfSamples synthetic copies

INPUT: 
    REF_LAYERS - list of layers of real network
    SYN_DATA[i] - list of <nbOfSamples> copies of real layer nb i-1
        
**************************************************************************
**************************************************************************
"""
    
        
"""
LAYER DEGREE GROUPS
"""

"""
prepare reference data for plot
@param:
    LAYERS - list with layers, simple graphs
    degA, degB - degree groups to be counted
@return:
    data - list with degree group counts
    degree_1 - one degree counts
    degree_A - degA counts
    degree_B - degB counts
"""
def layer_degree_groups_ref(LAYERS, degA=4, degB=10) :
    degree_1_data = []
    degree_A_data = []
    degree_B_data = []
    for L in LAYERS :
        degree_1 = len([n for n in L.nodes() if L.degree[n] == 1])
        degree_1_data.append(degree_1/L.number_of_nodes())
        degree_A = len([n for n in L.nodes() if L.degree[n] < degA])
        degree_A_data.append(degree_A/L.number_of_nodes())
        degree_B = len([n for n in L.nodes() if L.degree[n] < degB])
        degree_B_data.append(degree_B/L.number_of_nodes())
        
    return degree_1_data, degree_A_data, degree_B_data

"""
prepare synthetic data for boxplot
@param:
    SYN_DATA - list of lists with layers
    degA, degB - degree groups to be counted
@return:
    data for boxplot - list with degree group counts
    degree_1 - one degree counts
    degree_A - degA counts
    degree_B - degB counts
"""

def layer_degree_groups_syn(SYN_DATA, degA=4, degB=10) :
    degree_1_ratio_sample = []
    degree_A_ratio_sample = []
    degree_B_ratio_sample = []
    for SAMPLE in SYN_DATA: 
        degree_1_ratio = []
        degree_A_ratio = []
        degree_B_ratio = []
        for L in SAMPLE :
            degree_1 = len([n for n in L.nodes() if L.degree[n] == 1])
            degree_1_ratio.append(degree_1/L.number_of_nodes())
            degree_A = len([n for n in L.nodes() if L.degree[n] < degA])
            degree_A_ratio.append(degree_A/L.number_of_nodes())
            degree_B = len([n for n in L.nodes() if L.degree[n] < degB])
            degree_B_ratio.append(degree_B/L.number_of_nodes())
              
        degree_1_ratio_sample.append(degree_1_ratio)
        degree_A_ratio_sample.append(degree_A_ratio)
        degree_B_ratio_sample.append(degree_B_ratio)
    return degree_1_ratio_sample, degree_A_ratio_sample, degree_B_ratio_sample

    
"""
LAYER TRANSITIVITY, DENSITY and AVERAGE SHORTEST PATH
reference values and synthetic data for boxplot
"""
def layer_netstats_ref(LAYERS) :
    t_data = []
    d_data = []
    a_data = []
    for L in LAYERS :
        t_data.append(nx.transitivity(L))
        d_data.append(nx.density(L))
        L = max([L.subgraph(c) for c in nx.connected_components(L)], key=len)
        a_data.append(nx.average_shortest_path_length(L))
    return t_data, d_data, a_data

def layer_netstats_syn(SYN_DATA) :
    t_data = []
    a_data = []
    d_data = []
    for SAMPLE in SYN_DATA: 
        t_values = []
        a_values = []
        d_values = []
        for L in SAMPLE :
            t_values.append(nx.transitivity(L))
            d_values.append(nx.density(L))
            L = max([L.subgraph(c) for c in nx.connected_components(L)], key=len)
            a_values.append(nx.average_shortest_path_length(L))
        t_data.append(t_values)
        a_data.append(a_values)
        d_data.append(d_values)
    return t_data, d_data, a_data

    
"""
LAYERS boxplots with s-metric and hub counts
reference values and synthetic data for boxplot 
"""

def layer_smetric(REF_LAYERS, SYN_DATA):
    ref_sm = [nx.smetric.s_metric(L, normalized=False)/(L.number_of_edges()*L.number_of_edges()) for L in REF_LAYERS]
    syn_sm = []
    for SAMPLE in SYN_DATA: 
        syn_sm.append([nx.smetric.s_metric(L, normalized=False)/(L.number_of_edges()*L.number_of_edges()) for L in SAMPLE])
    sort_by_median(syn_sm, ref_sm)
    std_sm = comp_std(syn_sm, ref_sm)
    return syn_sm, ref_sm, std_sm
          
    
"""
**************************************************************************
**************************************************************************

STATISTICS TO COMPARE REAL NETWORK AND SYNTHETIC MULTIPLEX DATA SETS

real and synthetic network must have the same node, edge and layer size
synthetic data sets have equal nb of samples

INPUT: 
    REF_LAYERS - list of layers of real network
    MODELS_SAMPLE[i][j]
        j-th sample of layers of one synthetic multiplex of the model i
   
**************************************************************************
**************************************************************************
"""

"""
LAYER REPETITION HISTOGRAMS 
subplot for one data set in sample
histogram on layer repetition count of a given node set
@params
    NODE_SET - node set to count the layer repetition
    SYN_LAYERS - layers set of one data set 
    ax - axis to plot the histogram 
    colr, model - color and name of the model

@returns                                                                                                                                         
    list with average counts for nodes in NODE_SET
"""
def get_node_set(node_set, LAYERS):
    if node_set == 'hub':
        return mf.hubs_multiplex(LAYERS, False)
    elif node_set == 'node':
        MX = create_multiplex(LAYERS)
        return MX.nodes
    elif node_set == 'non-hub':
        MX = create_multiplex(LAYERS)
        hubs = mf.hubs_multiplex(LAYERS, False)
        return [node for node in MX.nodes if node not in hubs]
     

def subplot_layer_repetition(node_set, SYN_LAYERS, ax, color, plot=True):
    all_rep_vals = {key: 0 for key in range(1,len(SYN_LAYERS[0])+1)}
    
    min_v = len(SYN_LAYERS[0])
    max_v = 0
    
    for LAYERS in SYN_LAYERS :
        nodes = get_node_set(node_set, LAYERS)
        if len(nodes) > 0:  
            node_reptition = [layer_repetition_count(node, LAYERS) for node in nodes]
            rep_values = sorted(node_reptition, reverse=True)
            rep_valuesCnt = coll.Counter(rep_values)
            for val, cnt in rep_valuesCnt.items(): 
                if val > 0:
                    all_rep_vals[val] += cnt
                if plot:
                    ax.hist( rep_values, len(SYN_LAYERS[0]), histtype='step',
                             cumulative=-1, density=True, stacked=True, 
                             color=color, linewidth=0.5) #color='light'+color
                    
            min_v = min(min_v, min(node_reptition))
            max_v = max(max_v, max(node_reptition))
            
    # average counts 
    average_rep_counts_list = []
    for val, cnt in all_rep_vals.items():
        for _ in range(cnt): average_rep_counts_list.append(val)
        # add later to ax2 to put in front of the sample plots
      
    return average_rep_counts_list
   
        
"""
LAYER NODE AND EDGE SIZES
subplot for one data set 
    node sizes - plot_nodes=True
    edge sizes - plot_nodes=False
@returns 
    list with average counts
"""
def subplot_layer_sizes(ax, SYN_LAYERS, color, plot_nodes, plot=True):
    nbOfLayers = len(SYN_LAYERS[0])
    av_values = np.zeros(nbOfLayers)
    max_v = 0
    min_v = 100
    for LAYERS in SYN_LAYERS:
        if plot_nodes:
            N = [L.number_of_nodes() for L in LAYERS]
        else:
            N = [L.number_of_edges() for L in LAYERS]
        if plot:
            ax.hist( N, nbOfLayers, histtype='step', cumulative=-1, 
                    density=True, stacked=True, color=color, alpha=0.5) #color='light'+color,
        av_values += np.array(N)
        min_v = min(min_v, min(np.array(N)))
        max_v = max(max_v, max(np.array(N)))
        
    av_values /= len(SYN_LAYERS)
    av_values = [int(v) for v in av_values]
    
    return av_values  # to plot in front of all samples

"""
HUBS NETWORK

plot degree histograms for one data set in hub subnetwork 
    as simple graph (ax1)
    as multigraph (ax2)
@return:
    average degree counts simple and multigraph
"""
def subplot_hubnet_degree(ax1, ax2, SYN_LAYERS, color, model, plot=True):
    cum = -1
    all_deg_vals_M = {}
    all_deg_vals_S = {}
    layer_hubs_B = []
    
    min_S = min_M = 100
    max_S = max_M = 0
    
    for LAYERS in SYN_LAYERS:
        MLTPLEX = create_multiplex(LAYERS)
        hubs = mf.hubs_multiplex(LAYERS, False)
        if len(hubs) > 0 :
            hubs.sort()
            layer_hubs_B.append(hubs)
            H = MLTPLEX.subgraph(hubs) 
            SH = nx.Graph(H)
            degree_values_M = sorted([H.degree[k] for k in H.nodes], reverse=True)  
            degree_values_S = sorted([SH.degree[k] for k in SH.nodes], reverse=True)   
            
            min_S = min(min_S, min(degree_values_S))
            max_S = max(max_S, max(degree_values_S))
            min_M = min(min_M, min(degree_values_M))
            max_M = max(max_M, max(degree_values_M))
            
            if plot:
                ax1.hist( degree_values_S, H.number_of_nodes(), density=True, stacked=True, 
                         histtype='step', cumulative=cum, color='light'+color, alpha=0.5)
                ax2.hist( degree_values_M, H.number_of_nodes(), density=True, stacked=True, 
                         histtype ='step', cumulative=cum, color='light'+color, alpha=0.3)        
            # average
            valuesCnt = coll.Counter(degree_values_M)
            for val, cnt in valuesCnt.items(): 
                if val in all_deg_vals_M:
                    all_deg_vals_M[val] += cnt
                else:
                    all_deg_vals_M[val] = cnt            
                    
            valuesCnt = coll.Counter(degree_values_S)
            for val, cnt in valuesCnt.items(): 
                if val in all_deg_vals_S:
                    all_deg_vals_S[val] += cnt
                else:
                    all_deg_vals_S[val] = cnt
                
    # hist on all vals
    all_vals_list_M = []
    for val, cnt in all_deg_vals_M.items():
        for _ in range(cnt): all_vals_list_M.append(val)
    # hist on average vals
    all_vals_list_S = []
    for val, cnt in all_deg_vals_S.items():
        for _ in range(cnt): all_vals_list_S.append(val)
    return all_vals_list_S, all_vals_list_M
    


"""
STATISTICS ON A NETWORK AS A SIMPLE AND MULTIGRAPH
density, transitivity, average shortest path, betweenness
"""

"""
calculate network statistics on hub subnetwork (hub_network=True)
or multiplex otherwise for other plots

@return:
    density - two dimenttional data set with density for multi and simple graph
    transitivity - transitivity of simple graph, list with values per sample 
    asp - average shortest path, list with values per sample
    betweenness - list with values per sample
"""
def network_statisctics(SYN_LAYERS, hub_network):
    density = [[] for _ in range(2)]
    transitivity = []
    asp = []
    betweenness = []
    
    for LAYERS in SYN_LAYERS:
        MG = create_multiplex(LAYERS)
        
        if hub_network:
            hubs = mf.hubs_multiplex(LAYERS, False)
            hubs.sort()
            MG = MG.subgraph(hubs)
    
        if MG.number_of_nodes() > 0:
            SG = nx.Graph(MG) 
            density[0].append(round(nx.density(MG),4))
            density[1].append(round(nx.density(SG),4))
            transitivity.append(round(nx.transitivity(SG),4))
            SG.remove_nodes_from([k for k in SG.nodes if SG.degree[k] == 0])
            if SG.number_of_nodes() > 0:
                asp.append(stats.mean([stats.mean(nx.single_source_shortest_path_length(SG,j).values()) for j in SG.nodes]))
                betweenness.append(round(stats.mean(list(nx.betweenness_centrality(SG).values())),4))
    
    return density, transitivity, asp, betweenness
    

"""
MULTIPLEX DEGREE GROUPS IN LAYERS
counts nodes in degree groups =1 , >10, > 20, ... % of node size in a layers
@return
    dictionary with key - group, values - counts in layers
"""

def layer_degree_groups_count(LAYERS):
    # sort layers by 0-degree counts, normalized
    c0 =[]
    for L in LAYERS:
        if( nx.number_of_nodes(L) > 0) :
            degree_values = sorted([L.degree[k] for k in L.nodes])
            degCnt = collections.Counter(degree_values)
            c0.append(degCnt[1]/sum(degCnt.values()))
        else :
            c0.append(0.)

    # sort layers according to c0-order
    dc = {k: c0[k] for k in range(len(LAYERS))}
    dc_ord = collections.OrderedDict(sorted(dc.items(), key=lambda t: t[1]))
    ORD_LAYERS = []
    for k,_ in dc_ord.items():
        ORD_LAYERS.append(LAYERS[k])

    #calculate levels of degree counts, normalized
    data_counts = {"c0":[], "c10":[] , "c20":[] , "c30":[], "c40":[],
        "c50":[] , "c60":[] , "c70":[], "c80":[], "c90":[], "c100":[]}

    for L in ORD_LAYERS:
        assert(L.number_of_nodes() > 0)
        
        degree_values = sorted([L.degree[k] for k in L.nodes])
        max_deg = max(degree_values)
        degCnt = collections.Counter(degree_values)
        sumCnt = sum(degCnt.values())
        
        counts = np.zeros(11)
        for d, c in degCnt.items():
            for k in range(1,11) :
                if d <= 0.1 * k * max_deg :
                    counts[k] += c
        counts[0] = degCnt[1]
        
        for k in range(11) :
            nb = k*10
            data_counts["c"+str(nb)].append(counts[k]/sumCnt)

    return data_counts


"""
degree count in layers on a sample of layers
"""
def layer_degree_groups_count_SAMPLE(LAYERS_SAMPLE):
    nbOfSamples = len(LAYERS_SAMPLE)
    
    dat_cnts = layer_degree_groups_count(LAYERS_SAMPLE[0])
    S_dat_cnts = {}
    for k in dat_cnts.keys():
        S_dat_cnts[k] = np.zeros(len(LAYERS_SAMPLE[0]))
    
    for LAYERS in LAYERS_SAMPLE:
        dat_cnts = layer_degree_groups_count(LAYERS)
        for k, _ in dat_cnts.items():
            S_dat_cnts[k] += np.array(dat_cnts[k])

    # average values over sample set
    for k in S_dat_cnts.keys():
        S_dat_cnts[k] /= nbOfSamples
    
    return S_dat_cnts
 
    
"""
MULTIPLEX DEGREE DISTRIBUTION

degree histograms of one data set

@return
    average values
"""

def subplot_mx_degree(ax1, ax2, numberOfNodes, SYN_LAYERS, color, plot_all=True):
    av_degree_values = np.zeros(numberOfNodes)
    for LAYERS in SYN_LAYERS:
        MX = create_multiplex(LAYERS)
        deg_val = sorted([MX.degree[k] for k in MX.nodes])
        
        if plot_all:
            ax1.hist( deg_val, MX.number_of_nodes(), density=True, stacked=True, 
                     histtype='step', cumulative=-1,
                     color='light'+color, linewidth=0.5) 
            ax2.hist( deg_val, MX.number_of_nodes(), density=True, stacked=True, 
                     histtype='step', cumulative=-1, log=True, 
                     color='light'+color, linewidth=0.5)
        
        # average values, list have to have equal length            
        av_degree_values += np.array(deg_val)
    av_degree_values /= len(SYN_LAYERS)

    return av_degree_values

def subplot_mx_degree_log(ax, numberOfNodes, SYN_LAYERS, color, plot_all=True):
    av_degree_values = np.zeros(numberOfNodes)
    for LAYERS in SYN_LAYERS:
        MX = create_multiplex(LAYERS)
        deg_val = sorted([MX.degree[k] for k in MX.nodes])
        if plot_all:
            ax.hist( deg_val, MX.number_of_nodes(), density=True, stacked=True, #normed=1 
                     histtype='step', cumulative=-1, log=True, 
                     color=color, linewidth=0.5)
        
        # average values, list have to have equal length
        av_degree_values += np.array(sorted(deg_val))
    av_degree_values /= len(SYN_LAYERS)

    return av_degree_values
    
   
"""
Histograms compared in KS-Test should have equal values
"""
def ks_normalize(deg1, deg2):
    for k in range(min(deg1.keys()), max(deg1.keys()) ):
        if k not in deg1.keys():
            deg1[k] = deg1[k-1]
            
    for k in range(min(deg2.keys()), max(deg2.keys()) ):
        if k not in deg2.keys():
            deg2[k] = deg2[k-1]
        
    if len(deg1.items()) < len(deg2.items()):
        for k in range(max(deg1.keys())+1, max(deg2.keys())+1):
            deg1[k] = 0
    else: 
        for k in range(max(deg2.keys())+1, max(deg1.keys())+1):
            deg2[k] = 0
        
    
"""
KS-Test multiplex degree distribution, reference versus MODEL_SAMPlE
"""
def ks_test_degree_mpx(REF_LAYERS, MODELS_SAMPLE):
    REF_MX = create_multiplex(REF_LAYERS)
    ref_degree_values = sorted([REF_MX.degree[k] for k in REF_MX.nodes])
    dict_ref = ks_test(ref_degree_values)
    ks = {}
    for model, LAYERS in MODELS_SAMPLE.items():
        ks[model] = []
        for LAYER_SET in LAYERS:
            MX = create_multiplex(LAYER_SET)
            deg_val = sorted([MX.degree[k] for k in MX.nodes])
            dict_syn = ks_test(deg_val)
            ks_normalize(dict_syn, dict_ref) 
            diffs = []
            for  k, v in dict_syn.items():
                diffs.append(abs(v-dict_ref[k])) 
            n = len(dict_ref.items())
            dalpha = max(diffs)
            alpha = 2 * np.exp(-2*dalpha*dalpha*n)
            ks[model].append(round(alpha*100,2))  
 
"""
MULTIPLEX AVERAGE SHORTEST PATH AND CENTRALITY PER NODE

plot shortest path and centrality coefficient for one data set
@return:
    lists with average values
"""
def subplot_mx_sp_cc(ax1, ax2, nbOfNodes, SYN_LAYERS, color, model, plot_all=False):
    
    min_a_syn = []
    av_a_syn = []
    max_a_syn = []
    av_asp = np.zeros(nbOfNodes)
    for LAYERS in SYN_LAYERS: 
        M = create_multiplex(LAYERS)
        zero_deg = [k for k in M.nodes if M.degree[k] == 0]
        M.remove_nodes_from(zero_deg)
        asp = [stats.mean(nx.single_source_shortest_path_length(M,j).values()) for j in M.nodes]
        min_a_syn.append(min(asp))
        av_a_syn.append(stats.mean(asp))
        max_a_syn.append(max(asp))  
        
        asp.extend([0 for _ in zero_deg])  # it's not clean but has to be done to have equal length of added list 
        if plot_all:
            ax1.plot( sorted(asp), color, alpha=0.5)
        av_asp += sorted(np.array(asp))
    av_asp /= len(SYN_LAYERS)
    
    min_c_syn = []
    av_c_syn = []
    max_c_syn = []
    av_centr = np.zeros(nbOfNodes)
    for LAYERS in SYN_LAYERS: 
        M = create_multiplex(LAYERS)
        zero_deg = [k for k in M.nodes if M.degree[k] == 0]
        M.remove_nodes_from(zero_deg)
        cc = list(nx.closeness_centrality(M).values())
        min_c_syn.append(min(cc))
        av_c_syn.append(stats.mean(cc))
        max_c_syn.append(max(cc))  
        cc.extend([0 for _ in zero_deg])
        if plot_all:
            ax2.plot( sorted(cc), color, alpha=0.5)
        av_centr += sorted(np.array(cc))  
    av_centr /= len(SYN_LAYERS)
        
    return av_asp, av_centr

      
"""
plot layer examples of all models and the reference
""" 
def plot_compare_layers_all(MODELS_SAMPLE, settings):
    
    color_to_model, fig_prefix = settings
    
    LAYERS = []
    model = []
    color = []
    for m, LSET in MODELS_SAMPLE.items():
        model.append(m) 
        color.append(color_to_model[m])
        LIST = sort_layers_by_nodesize(LSET[0], reverse= True)
        LAYERS.append(LIST)
      
    plt.figure(figsize = (6, 10))
    plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                wspace=0.01, hspace=None)
    r = 3
    c = 3
    for i in range(r):
        for j in range(c):
            l = random.choice(range(len(LAYERS[i])))
            L = LAYERS[i][l]
            L.remove_nodes_from([n for n in L.nodes if L.degree[n]==0])
            ax = plt.subplot2grid((r,c), (i,j))
            plt.sca(ax)
            plt.axis('off')
            pos = nx.spring_layout(L)
            nx.draw_networkx_nodes(L, pos, alpha=0.8, node_color = 'black', node_size=5)
            nx.draw_networkx_edges(L, pos, width=1.0, alpha=0.5, edge_color = color[i])
            if j == 0:
                plt.title(model[i])
        
    plt.savefig(fig_prefix+'LayerExamples.png')
    plt.show

    
"""
LAYER INTERSECTION

intersection of a layer with another layer 
percentage of common nodes
"""
def get_intersection_data(LAYERS):
    LAYERS = sort_layers_by_nodesize(LAYERS)
    layer_prc = []
    index = []
    for L1 in LAYERS:
        inter_cnt = []
        nset1 = sorted(L1.nodes)
        for L2 in LAYERS :
            if L1 != L2:
                nset2 = sorted(L2.nodes)
                intersect = [x for x in nset1 if x in nset2]
                inter_cnt.append(int(100*(len(intersect)/L1.number_of_nodes())))
        layer_prc.append(inter_cnt)
        index.append(L1.number_of_nodes())
        
    #sort by median
    for _ in range(len(layer_prc)) :
        for j in range(len(layer_prc) - 1):
            if stats.median(layer_prc[j]) > stats.median(layer_prc[j+1]) :
                temp = layer_prc[j]
                layer_prc[j] = layer_prc[j+1]
                layer_prc[j+1] = temp
                val = index[j]
                index[j] = index[j+1]
                index[j+1] = val
    return layer_prc, index


def plot_compare_layer_intersection(MODELS_SAMPLE, settings):
    
    color_to_model, fig_prefix = settings
    
    plt.figure(figsize = (10, 4), dpi=1000)  
    plt.subplots_adjust(left=None, bottom=0.3, right=None, top=0.7,
                wspace=0.06, hspace=0.5)
    r = 1
    c = len(MODELS_SAMPLE.items())
    i = 0
    for model, LSET in MODELS_SAMPLE.items():
        ax = plt.subplot2grid((r,c), (0,i))
        i += 1
        LAYERS = random.choice(LSET)
        layer_prc, _ = get_intersection_data(LAYERS)        
        bp = ax.boxplot(layer_prc, vert=True, patch_artist=True, showfliers=False)
        color = color_to_model[model]
        set_box_color(bp, c1=color, c2=color, c3=color, c4='black')
        ax.text(3, 85, model, bbox=dict(facecolor='none', edgecolor=color))
        ax.set_xlabel('layers')
        if i == 1:
            ax.set_ylabel('% of nodes in intersec.')
        ax.set_ylim(-1,100)
        plt.setp(ax.get_xticklabels(), visible=False)
        plt.setp(ax.get_xticklines(), visible=False)
        if i > 1:
            plt.setp(ax.get_yticklabels(), visible=False)
            plt.setp(ax.get_yticklines(), visible=False)
        
     
    plt.savefig(fig_prefix+'MX_layerIntersection.png', transparent=True)
    plt.show()
    
    
"""
MESO-SCALE STRUCTURE
"""

"""
VARIANCE OF DEGREE DISTRIBUTION (BINBALL)
mean = (sum deg(u) per layer)/ nb_of_layers 
variance = (sum deg(u) per layer)^2/ nb_of_layers - mean^2
@param:
    M - multiplex
    LAYERS - layers
@return:
    var_deg - dictionary {node: degree var}
"""
def degree_variance(M, LAYERS):
    nodes = sorted(M.degree, key=lambda x: x[1])
    var_deg = {}
    for (node, _) in nodes:
        deg = []
        deg2 = []
        for L in LAYERS:
            if node in L.nodes():
                deg.append(L.degree[node])
                deg2.append(L.degree[node]*L.degree[node]) 
            else:
                deg.append(0)
                deg2.append(0)
        mean_ldeg = sum(np.array(deg))/len(LAYERS)
        var_deg[node] = sum(np.array(deg2))/len(LAYERS) - mean_ldeg*mean_ldeg
    return var_deg

"""
COSINE SIMILARITY
LAYERS_UR --> upper right corner
LAYERS_LL -> lower left corner
"""
def cosine_similarity(LAYERS_UR, LAYERS_LL):
    from math import sqrt
    M = create_multiplex(LAYERS_UR)
    mxr = nx.to_numpy_matrix(M, nodelist=[n for (n,_) in sorted(M.degree, key=lambda x: x[1])])
    mxs = np.zeros(mxr.shape)
    if len(LAYERS_LL) > 0:
        M = create_multiplex(LAYERS_LL)
        mxs = nx.to_numpy_matrix(M, nodelist=[n for (n,_) in sorted(M.degree, key=lambda x: x[1])])
    cm = np.zeros(mxr.shape)
    
    # lists with values for stats
    cmListUR = [] 
    cmListLL = []
    for i in range(M.number_of_nodes()):
        for j in range(i+1,M.number_of_nodes()):
            sumr = np.zeros(3)
            sums = np.zeros(3)
            for k in range(M.number_of_nodes()):
                sumr[0] += mxr[i,k] * mxr[k,j]
                sumr[1] += mxr[i,k] * mxr[i,k]
                sumr[2] += mxr[k,j] * mxr[k,j]
                if len(LAYERS_LL) > 0:
                    sums[0] += mxs[i,k] * mxs[k,j]
                    sums[1] += mxs[i,k] * mxs[i,k]
                    sums[2] += mxs[k,j] * mxs[k,j]
            cm[i,j] = sumr[0] /(sqrt(sumr[1]) * sqrt(sumr[2])) 
            cm[j,i] = cm[i,j]
            cmListUR.append(cm[i,j])
            if len(LAYERS_LL) > 0:
                cm[j,i] = sums[0] /(sqrt(sums[1]) * sqrt(sums[2]))
                cmListLL.append(cm[j,i])
                
    # mean and std
    cmStats = [stats.mean(cmListLL), stats.stdev(cmListLL), stats.mean(cmListUR), stats.stdev(cmListUR)]
    cmStats = [round(k,3) for k in cmStats]
    return cm, cmStats


"""
ASSORTATIVITY COEFFICIENT
"""
def assortivity_coef(G):
    nodes = [n for (n,_) in sorted(G.degree, key=lambda x: x[1])]    
    adj_mx = nx.to_numpy_matrix(G, nodelist=nodes)
    ass_coef_nom = 0
    ass_coef_den = 0
    m = G.number_of_edges()
    for i in range(G.number_of_nodes()):
        degi = 0
        for j in range(i,G.number_of_nodes()):
            degij = G.degree[nodes[i]]*G.degree[nodes[j]]
            if i == j: 
                degi = G.degree[nodes[i]]
                ass_coef_nom += (adj_mx[i,j] - degij/(2*m)) / degij
                ass_coef_den += (degi - degij/(2*m)) / degij
            else:
                ass_coef_nom += 2*(adj_mx[i,j] - degij/(2*m)) / degij
                ass_coef_den += 2*(degi - degij/(2*m)) / degij
    return ass_coef_nom/ass_coef_den
            
        
