#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
author: Tobias Lory & Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

runs with 
Python 3.8.11 
networkx 2.6.2
'''


import networkx as nx 
import numpy as np
import random
import scipy.stats as sstats
from itertools import combinations
import collections

# local python module
import mx_functions as mf


"""
to keep equal node and edge size for multiplex comparisons
routine called at the end of creation of any synthetic multiplex
1) connect zero degree nodes if thera a any
2) if there is an overhead of edges, removed it
"""  

def mx_remove_edge_overhead(M, LAYERS, nbOfEdges):  
    # connect zero degree nodes
    Z = [n for n in M.nodes if M.degree[n] == 0]
    for start in Z:
        # add zero degree node to some randomly selected layer and node
        L = random.choice(LAYERS)
        end = random.choice([n for n in L.nodes if n != start])
        L.add_edge(start, end)
        M.add_edge(start, end)
         
    # we may end up with too many edges -> remove the overhead
    for _ in range(M.number_of_edges() - nbOfEdges):
        edge_removed = False
        # a few trials 
        i = 10
        while not edge_removed and i > 0:
            L = random.choice(LAYERS)
            edges_to_remove = [ (u,v) for (u,v) in L.edges if L.degree[u] > 1 and L.degree[v] > 1]
            random.shuffle(edges_to_remove)
            while not edge_removed and len(edges_to_remove) > 0:
                edge = edges_to_remove.pop(0)
                G = L.copy()
                G.remove_nodes_from([n for n in G.nodes if G.degree[n] == 0])
                G.remove_edge(*edge)
                if nx.is_connected(G):
                    L.remove_edge(*edge)
                    M.remove_edge(*edge)
                    edge_removed = True
            i -= 1  


"""""""""""""""""""""""""""""
MODEL 1: BINBALL
"""""""""""""""""""""""""""""

"""
Create a random multiplex-network according to the BINBALL model
see https://ieeexplore.ieee.org/document/7403577

@param:
    nbOfNodes - number of nodes
    nbOfEdges - number of edges
    nbOfLayers - number of layers
    zeroAppeal - global weighting vector
    alpha - degree scaling factor
default values are set according to Basu et al. except number of nodes, see below

@return:
    LAYERS - list of layers (simple graph objects)
    M - multiplex (a multigraph object)
"""

def binball (
        nbOfNodes = 417,
        nbOfEdges = 3588,
        nbOfLayers = 37,
        zeroAppeal = 0.9,
        alpha = 1.
 ) :
    # initialize the multiplex and the layers
    M = nx.MultiGraph()
    M.add_nodes_from(range(nbOfNodes))
    LAYERS = []
    for _ in range(nbOfLayers):
        LAYERS.append(nx.Graph())
    
    # distribute uniformly nodes among layers
    for node in range(nbOfNodes):
        L = random.choice(LAYERS)
        L.add_node(node)
    
    repeat = False
    for L in LAYERS:
        if len(list(L.nodes)) == 0:
            repeat = True
            break;
     
    while repeat:
        for node in range(nbOfNodes):
            L = random.choice(LAYERS)
            L.add_node(node)
        repeat = False
        for L in LAYERS:
            if len(list(L.nodes)) == 0:
                repeat = True
                break;
            

    # initial network to iniatiate the global preferential attachment
    P = nx.barabasi_albert_graph(nbOfNodes, 1)
    
    global_degrees = np.array([P.degree[k] for k in M.nodes]) + zeroAppeal
    
    ### THE MAIN LOOP ###
    # add edges to layers and multiplex one by one
    for _ in range(nbOfEdges):
        #select a layer 
        L = LAYERS[random.choice(range(nbOfLayers))]
        
        # select the start node of the current new edge with respect to high local degree
        # random choice if layer is empty
        if L.number_of_edges() == 0:
            startnode = random.choice(list(L.nodes))
        # else: local preferential attachment
        else:
            # calculate local degree distriburtion
            layer_degrees = {k: alpha*L.degree[k] + zeroAppeal for k in L.nodes}
            sum_layer_degrees = sum(layer_degrees.values())
            layer_distr = {k: v/sum_layer_degrees for k, v in layer_degrees.items()}
            nodes_vec = list(layer_distr.keys())
            localdistr_vec = list(layer_distr.values())
   
            startnode = np.random.choice(nodes_vec,size=1,p=localdistr_vec)[0]
            
        globalDistr = global_degrees/global_degrees.sum()
        endnode = np.random.choice(range(nbOfNodes), 1, p=globalDistr)[0]
        
        while startnode == endnode \
            or L.has_edge(startnode, endnode) \
            or L.has_edge(endnode, startnode) :
                endnode = np.random.choice(range(nbOfNodes), 1, p=globalDistr)[0]


        L.add_edge(startnode, endnode)
        M.add_edge(startnode, endnode)
        global_degrees[startnode] += alpha;
        global_degrees[endnode] += alpha;
    
    """
    the number of edges might exceed that one given as a parameter
    to keep predicted edge size e.g. for multiplex comparisons
    uncomment the folowing line 
    """
    #mx_remove_edge_overhead(M, LAYERS, nbOfEdges)
    
    
    return LAYERS, M


"""
create data sets with multiplex and corresponding layer list
takes over default values form binball
"""
def sample_binball(nbOfSamples = 100) :
    MSAMPLE = []
    LSAMPLE = []
    for _ in range(nbOfSamples) :
        L, M = binball()
        MSAMPLE.append(M)
        LSAMPLE.append(L)
        
    return LSAMPLE, MSAMPLE


"""""""""""""""""""""""""""""
MODEL 2: STARGEN
"""""""""""""""""""""""""""""

"""
calculate current local degree distriburtion of a layer L
"""
def getLocalDistr(L, alphaloc) :
    layer_degrees = {k: pow(L.degree[k],alphaloc) for k in L.nodes}
    sum_layer_degrees = sum(layer_degrees.values())
    layer_distr = {k: v/sum_layer_degrees for k, v in layer_degrees.items()}
    return list(layer_distr.keys()), list(layer_distr.values())

"""
Create a random multiplex-network according to the STARGEN model
see https://faculty.nps.edu/rgera/papers/2017-STARGEN-Marzena-OR.pdf

@param:
    nbOfLayers - number of layers
    nbOfNodes - number of nodes
    nbOfEdges - number of edges
    zeroAppeal - global weighting vector
    alphaloc_min, alphaloc_max - range of local degree scaling factors
    alphaglob - global degree scaling factor
    
@return:
    LAYERS - list of layers (simple graph objects)
    M - multiplex (a multigraph object)
"""

def stargen(
        nbOfLayers = 37,             # layers count
        nbOfNodes = 417,             # nodes count
        nbOfEdges = 3588,            # edges count
        zeroApp = 1.1,               # zero appeal
        alphaloc_min = 1.1,          # local alpha range
        alphaloc_max = 1.8,          
        alphaglob = 1.0
) :
    
    # initialize multiplex 
    M = nx.MultiGraph()
    M.add_nodes_from(range(nbOfNodes))
    globalDegreeVals = np.zeros(nbOfNodes) + zeroApp
    
    # initialize layers      
    LAYERS = [nx.Graph() for i in range(nbOfLayers)]   
        
    # layer edge size follows the powerlaw
    P = nx.barabasi_albert_graph(nbOfLayers, 1)
    layerDistr = np.array([P.degree[k] for k in P.nodes])
    layerDistr = layerDistr/sum(layerDistr)  
    
    # assign alpha to layer
    layerAlpha = np.round(np.random.uniform(alphaloc_min, 
                                            alphaloc_max, nbOfLayers), 2)
    #sort alpha in decreasing order while layerDistr values increase
    layerAlpha = sorted(layerAlpha, reverse=True)
    layerDistr = sorted(layerDistr)

    # add adges to the network    
    for e in range(nbOfEdges):      
        layerNb  = np.random.choice(range(nbOfLayers), 1, p = layerDistr)[0]
        L = LAYERS[layerNb]   # the layer
                
        # avoid too many nodes in a layer
        if L.number_of_nodes() >  0.25*nbOfNodes :
            endnodes = np.random.choice(list(L.nodes), 2, replace= False)
            start = endnodes[0]
            end = endnodes[1]
        else :
            nodes, localDistr = getLocalDistr(L, layerAlpha[layerNb])                      
            if L.number_of_edges() == 0:
                start = random.choice(list(M.nodes))
            else:   
                start = np.random.choice(nodes, 1, p=localDistr)[0]  
            globalDistr = globalDegreeVals/globalDegreeVals.sum()
            end = np.random.choice(range(nbOfNodes), 1, p=globalDistr)[0]
            
        i = 0
        while start == end or L.has_edge(start, end) or L.has_edge(end, start) :
            Z = [n for n in M.nodes if M.degree[n] == 0]
            if i%2 == 0 and len(Z) > 0 and e > 0.9*nbOfEdges:
                end = random.choice(Z)
            else:
                end = random.choice(list(M.nodes)) 
            i +=1
            if i%100==0:
                print('e',e,'i',i)

        # update layer and multiplex
        L.add_edge(start, end)
        M.add_edge(start, end)
        
        # update global degree distribution
        globalDegreeVals[start] += alphaglob
        globalDegreeVals[end] += alphaglob

    """
    the number of edges might exceed that one given as a parameter
    to keep predicted edge size e.g. for multiplex comparisons
    uncomment the folowing line 
    """
    #mx_remove_edge_overhead(M, LAYERS, nbOfEdges)
                
    return LAYERS, M

"""
create data sets with multiplex and corresponding layer list
takes over default values form starGen
"""
def sample_starGen(nbOfSamples=100 ):
    MULTIPLEXES = []
    LAYERS = []
    for _ in range(nbOfSamples):
        L, M = stargen( )      
        MULTIPLEXES.append(M)
        LAYERS.append(L)
    return LAYERS, MULTIPLEXES


"""""""""""""""""""""""""""""""""""
MODEL 3: ANGEL - AUXILIARY METHODS
"""""""""""""""""""""""""""""""""""


"""
create a complete graph on nodes with positions in attributes and calculate 
minimum spanning tree with edge weights - distances between end nodes
@param:
    L - graph with set of nodes with positions in attributes 
@return:
    T - minimum spanning tree on complete weighted simple graph 
"""
def mst_on_compl_graph(L):
    G = nx.Graph()
    for n, m in combinations(list(L.nodes), 2):
        G.add_edge(n, m, weight=mf.dist(L, n, m))
    G = nx.Graph(G) # remove multiple edges
    T = nx.minimum_spanning_tree(G)
    compact_tree(T)
    L.add_edges_from(T.edges)

"""
reduce k-deg-nodes in graph G
    for each k-degree node n in G:
        find its neighbor m with the highest degree 
        connect all other neighbours of n to m
@param
    G - the graph, usually a tree
    k - the degree of nodes to move

"""
def contract_k_deg_nodes(G, k):
    DEGKNODES = [ n for n in G.nodes() if G.degree[n] ==  k ]
    for node in DEGKNODES:
        if G.degree[node] ==  k: #degree might have changed within previous iterations
            # neighbors: N = [n for n in G[node] ]
            LIST = [n for n,_ in sorted(G.degree(G[node]), key=lambda x: x[1], reverse=True)]
            nnode = LIST[0] #neighbor with highest degree 
            # detach node from its neighbors
            for n in LIST:
                mf.remove_edge(G, node,n)
            # attach node and its neighbors to nnode
            LIST.remove(nnode)
            LIST.append(node)
            
            for n in LIST:
                G.add_edge(nnode, n)


"""
reduce 1 and 2 degree nodes, then remove leaves and 
reduce 1 and 2 degree nodes in the new graph
add leaves to the new graph
"""
def compact_tree(T):
    contract_k_deg_nodes(T, 2)
    
    LEAVES = [ n for n in T.nodes() if T.degree[n] ==  1 ]
    LEAF_EDGES = []
    for leaf in LEAVES:
        [nleaf] = [n for n in T[leaf] ]
        LEAF_EDGES.append((nleaf, leaf))
        
    T.remove_edges_from(LEAF_EDGES) 
    # the tree is now a path, compact it 
    contract_k_deg_nodes(T, 2)
    # add the previously removed leaves
    T.add_edges_from(LEAF_EDGES) 
    

"""
HAS-LAYER REPLICATION
has - hub-and-spoke 
"""

"""
subroutines
"""

# move leaves to the closets hubs
def leaves_to_closer_hub(L, hubs):
    if len(hubs) > 1:
        LEAVES = [node for node in L.nodes if L.degree[node] == 1]
        for l in LEAVES:
            hub2dist = dict(zip(hubs, [mf.dist(L, l, h) for h in hubs]))
            h, _ = sorted(hub2dist.items(), key=lambda x: x[1]).pop(0)
            if (h != l):
                [n] = L.neighbors(l)
                if not L.has_edge(l,h) and not L.has_edge(h,l):
                    if L.has_edge(l,n): L.remove_edge(l,n)
                    if L.has_edge(n,l): L.remove_edge(n,l)
                    L.add_edge(l,h)
     
# add leftover edges to given hubs
def edges_to_hubs(L, hubs, nbOfEdges):
    if len(hubs) > 1:
        leaves_to_closer_hub(L, hubs)
        # select nodes for the bridges - connected to two hubs
        # for that create a list with potential new edges sorted by distance
        H = nx.Graph()
        for n, m in combinations(list(L.nodes), 2):
            if ((n in hubs and m not in hubs) or (m in hubs and n not in hubs)):
                H.add_edge(n, m, weight=mf.dist(L,n,m))
        H.remove_edges_from(L.edges)
        HEDGES = sorted(H.edges(data=True), key=lambda x: x[2]['weight'])
    
        # connect hubs with nodes (connected to other hubs) but close to them   
        sm = nx.smetric.s_metric(L, normalized=False)/(L.number_of_edges()*L.number_of_edges())            
        edges_nb = int(max((1-sm), 0.1) * nbOfEdges)
                      
        while edges_nb > 0 and nbOfEdges > L.number_of_edges() and len(HEDGES) > 0:
            i, j, data = HEDGES[0]
            L.add_edge(i,j, weight=data['weight'])
            edges_nb -= 1
            HEDGES.remove(HEDGES[0])
            
    # the left over edges connect high degree nodes with low degree nodes
    if nbOfEdges > L.number_of_edges():
        # preferable not leaves and not hubs
        if len([n for n in L.nodes if L.degree[n] > 1 and n not in hubs]) > 10:
            H = nx.Graph(L)
            H.remove_nodes_from([n for n in L.nodes if L.degree[n]== 1 or n in hubs])
            
            for _ in range(nbOfEdges - L.number_of_edges() ):
                degree = {k: max(1, L.degree[k]) for k in H.nodes}
                nodes_vec = [k for k, v in degree.items()]
                distr_vec = [v/sum(degree.values()) for k, v in degree.items()]
                
                start, end = np.random.choice(nodes_vec, size=2, replace = False, p = distr_vec)
                runs = 0
                while (L.has_edge(start, end) or L.has_edge(end, start)) and runs < 10:
                    start, end = np.random.choice(nodes_vec, size=2, replace = False, p = distr_vec)
                    runs += 1
                      
                if not (L.has_edge(start, end) or L.has_edge(end, start)):
                    L.add_edge(start, end)
        
        for _ in range(nbOfEdges - L.number_of_edges() ):
            degree = {k: L.degree[k] for k in L.nodes if k not in hubs}
            for k, v in degree.items():
                if v == 0: v = 1
            nodes_vec = [k for k, v in degree.items()]
            distr_vec = [v/sum(degree.values()) for k, v in degree.items()]
        
            start, end = np.random.choice(nodes_vec, size=2, replace = False, p = distr_vec)
            while L.has_edge(start, end) or L.has_edge(end, start) :
                start, end = np.random.choice(nodes_vec, size=2, replace = False, p = distr_vec)
            L.add_edge(start, end)
            
        # move leaves to the closets hubs
        leaves_to_closer_hub(L, mf.hubs_layer(L)) 
            
        assert(nbOfEdges == L.number_of_edges())
        
        
"""
HAS-LAYER within a multiplex

the replication is performed in three steps: 
(mx1) compute minimum spanning tree on the grid nodes according to their distances
   move leaves along the tree till hubs are built

intermediate step in angel_multiplex: after hubs are encountered, 
the a network on hubs across all layers in the multiplex is created

(mx2) add remaining edges to the layer

"""
  
def angel_layer_has_mx1(L, nbOfEdges) :
    # calculate a minimum spanning tree on a complete graph 
    # based on the to distances between the nodes
    # and perform a basic contraction
    mst_on_compl_graph(L)
    
    # contract the tree till hubs in the given number unfold
    # some random number for s_metrics
    sm = random.random() * 0.3 + 0.7
    nb_of_hubs = mf.set_nb_of_hubs(sm, L.number_of_nodes()/nbOfEdges )
    k = 1
    while len(mf.hubs_layer(L)) == 0 or len(mf.hubs_layer(L)) > nb_of_hubs and k < 100:
        contract_k_deg_nodes(L, k)
        k += 1

    hubs = mf.hubs_layer(L) 
    if len(hubs) == 0: # we need at least 1 hub
        hubs.append(random.choice(L.nodes))
    
    # label hubs in L
    for h in hubs:
        L.nodes[h]['hub'] = 'H'
    
    # once hubs are assigned move all leaves to the closest hub
    leaves_to_closer_hub(L, hubs)
    #  we have hubs in the layer

def angel_layer_has_mx2(L, nbOfEdges) :   
    hubs = [n for n, h in nx.get_node_attributes(L,'hub').items() if h == 'H']
    edges_to_hubs(L, hubs, nbOfEdges)
        
"""
HAS-LAYER for a SINGLE REPLICATION

create a hub-and-spoke layer for ANGEL multiplex with a specified value of s-metric

@param:
    nbOfNodes - number of nodes, which will be added to the layer
    nbOfEdges - number of edges, which will be added to the layer
    pos - (optionally) if non zero length, the position of the nodes should be overtaken
        its a dictionary with entries (nb, (x, y))
    s_metric - a value for s-metric to be mimicked
@return: layer, simple graph
"""

def angel_layer_has(nbOfNodes, nbOfEdges, pos, s_metrics) :
    L = nx.Graph()
    mf.add_nodes_with_pos(L, nbOfNodes, pos)
    pos = nx.get_node_attributes(L, 'pos')
        
    # calculate a minimum spanning tree on a complete graph 
    # based on the to distances between the nodes
    # and perform a basic contraction
    mst_on_compl_graph(L)
       
    # contract the tree till hubs in the given number unfold
    set_hubs_nb = mf.set_nb_of_hubs(s_metrics, nbOfNodes/nbOfEdges )
    hubs_nb = len(mf.hubs_MST(L))
    T = L.copy()
    k = 2
    max_degree = max([L.degree[n] for n in L.nodes])
    while k < max_degree and ( set_hubs_nb != hubs_nb 
                               or set_hubs_nb < hubs_nb 
                               or len(mf.hubs_MST(T)) > hubs_nb ):
        k += 1
        T = L.copy()
        contract_k_deg_nodes(L, k)
        hubs_nb = len(mf.hubs_MST(L))
        max_degree = max([L.degree[n] for n in L.nodes])      

    if len(mf.hubs_MST(T)) > hubs_nb:
        L = T.copy()
        nx.set_node_attributes(L, pos, 'pos')
        
    hubs = mf.hubs_MST(L)
    edges_to_hubs(L, hubs, nbOfEdges)
    return L


"""
PTP-LAYER (point-to-point)

add edges based on probabilities according to their length
to avoid too short and too long distances we use the normal distribution
add randomly pick up nodes with lengths from "under the bell"

@param
    L - layer, a simple graph
    nbOfEdges - number of edges to be added
"""

"""
subroutines
"""
def add_edges_pa(L, nbOfEdges):
    # create a complete graph on nodes in L
    H = nx.Graph()
    for n, m in combinations(list(L.nodes), 2):
        H.add_edge(n, m, weight=mf.dist(L,n,m))
    H.remove_edges_from(L.edges) # discard edges in layer already
    
    # sort edges in H by their weight
    edges = []
    weights = []
    for i, j, data in sorted(H.edges(data=True), key=lambda x: x[2]['weight']):
        edges.append((i,j))
        weights.append(data['weight'])
    
    # norm_vals are normally distributed values with mean and sigma
    # based on edge weights in H, in the length of nb_of_edges in H
    mu = np.mean(weights)
    sigma = np.std(weights)
    min_dist = min(weights)
    norm_vals = sorted([max(min_dist,v) for v in np.random.normal(loc=mu, scale=sigma, size=nbOfEdges)])  
    
    # for each value in norm_vals find an edge in H with weight close to this value
    # if not found take an edge with value at median
    for wn in norm_vals:
        found = False
        index = 0
        while not found and index < len(edges) - 1:
            if weights[index] <= wn and wn <= weights[index+1]:
                found = True
            index += 1
        index -= 1
        if not found:
            index = int((len(edges) - 1)/2)
            
        (n,m) = edges[index]
        L.add_edge( n, m , weight=weights[index] )
        edges.pop(index)
        weights.pop(index)    
        nbOfEdges -= 1

    assert(nbOfEdges == 0)

        
"""
PTP-LAYER within a multiplex
"""
def angel_layer_ptp_mx(L, number_of_edges):
    mst_on_compl_graph(L)
    
    if number_of_edges - L.number_of_edges() > 10:
        add_edges_pa(L, int((number_of_edges - L.number_of_edges()) * random.random()) )
    
    for _ in range(number_of_edges - L.number_of_edges() ):
        degree = {k: L.degree[k] for k in L.nodes}
        for k, v in degree.items():
            if v == 0: v = 1
        nodes_vec = [k for k, v in degree.items()]
        distr_vec = [v/sum(degree.values()) for k, v in degree.items()]
        start, end = np.random.choice(nodes_vec, size=2, replace = False, p = distr_vec)
        
        k = 0       # to avoid an endless loop
        while (L.has_edge(start, end) or L.has_edge(end, start) ) and k < 20:
            start, end = np.random.choice(nodes_vec, size=2, replace = False, p = distr_vec)
            k += 1
        
        L.add_edge(start, end)
        
        
"""
PTP-LAYER for a single replication
"""
def angel_layer_ptp(number_of_nodes, number_of_edges, pos):
    L = nx.Graph()
    mf.add_nodes_with_pos(L, number_of_nodes, pos)
    angel_layer_ptp_mx(L, number_of_edges)
    assert(number_of_edges == L.number_of_edges())
    return L 
 


"""""""""""
the ANGEL multiplex creation method
see https://ieeexplore.ieee.org/document/8954628

@param:
    nbOfLayers  - number of layers in the multiplex
    nbOfNodes  - number of (non zero degree) nodes in the multiplex
    nbOfEdges - number of edges in the multiplex
    layerRscale - probability distribution of the layer repetition count 
    nodeLoc, nodeScale - expon.rvs.loc and expon.rvs.scale 
                        for layer node sizes probability distribution
    edgeLoc, edgeScale - expon.rvs.loc and expon.rvs.scale 
                        for layer edge sizes probability distribution
    
default values are derived from EATN
by varying the number of layers/nodes/edges the probability distribution
have to be fitted

@return:
    list of layers in the multiplex
"""

#parameter set for EATN
def angel_multiplex(
      nbOfLayers = 37,
      nbOfNodes = 417,
      nbOfEdges = 3588,
      layerRscale = 3.88,  # expon.rvs for layer repetition
      nodeLoc = 40,        # expon.rvs.loc for layer node sizes
      nodeScale = 20,      # expon.rvs.scale for layer node sizes
      edgeLoc = 40,        # expon.rvs.loc for layer edge sizes
      edgeScale = 60       # expon.rvs.scale for layer edge sizes
    ):
    
    # list of simple graph objects for the layers
    LAYERS = [nx.Graph() for l in range(nbOfLayers)]    
    GRID = mf.grid_positions(nbOfNodes)   # node positions on a grid
    
    """
    Step 1.1, NODES TO LAYERS
    """
    # layer repetition count per node
    layerRep = sstats.expon.rvs(loc=1, scale=layerRscale, size=nbOfNodes) #scale=2.54 for nonhub
    # integer values within [1, nbOfLayers] allowed
    # sort values decreasingly to distribute first nodes with the high layer repetition
    layerRep = np.minimum(nbOfLayers, np.maximum(1, layerRep))
    layerRep = sorted([int(n) for n in layerRep], reverse=True)

    # layer node sizes 
    sample = sstats.expon.rvs(loc=nodeLoc, scale=nodeScale, size=nbOfLayers)
    PnodeL = sample/sum(sample)
                     
    # DISTRIBUTE NODES AMONG LAYERS
    for node_nb in range(nbOfNodes) :
        # sample layers for a node
        layers = np.random.choice(range(nbOfLayers), size=layerRep[node_nb], p = PnodeL, replace=False)
        # add node to the selected layers
        for l in layers: LAYERS[l].add_node(node_nb, pos=GRID[node_nb], hub='N')
        
    """
    Step 1.2, ASSIGN EDGE COUNT
    """
    # distribution of layer edge sizes   
    sample = sstats.expon.rvs(loc=edgeLoc, scale=edgeScale, size=nbOfLayers)

    # if the total number of edges is too small or too high
    while sum([int(s) for s in sample]) < 0.9*nbOfEdges or sum([int(s) for s in sample]) > nbOfEdges:
        sample = sstats.expon.rvs(loc=edgeLoc, scale=edgeScale, size=nbOfLayers)

    # to enforce the tail
    sample = sorted([int(s) for s in sample],reverse=True)
    for i in range(int(.1*nbOfLayers)):
        sample[i] += 0.5*sample[i]
        
    # assign edge sizes to layers, the biggest node size gets the biggest edge size
    # EDGE_SIZES[k] corresponds to LAYERS[k]
    EDGE_SIZES = sorted([int(s) for s in sample], reverse=True)
    
    LAYERS = sorted(LAYERS, key = lambda x:x.number_of_nodes(), reverse=True) 
    # make sure that nbOfEdges > nbOfNodes in each layer using edges from big layers 
    for k in reversed(range(nbOfLayers)):
        while EDGE_SIZES[k] < LAYERS[k].number_of_nodes()-1:
            max_k = np.random.choice(range(3), size=1)[0]
            EDGE_SIZES[k] += 1
            EDGE_SIZES[max_k] -= 1
        assert(EDGE_SIZES[k] >= LAYERS[k].number_of_nodes()-1)
    
    edge_size = dict(zip(LAYERS, EDGE_SIZES))
    
    """
    Step 2 HUBS
    """
    # select 10% of the layers to be PTP (point to point) the rest is HAS (hub and spoke) 
    LAYERS_PTP = random.sample(LAYERS, int(.1 * nbOfLayers))
    LAYERS_HAS = [L for L in LAYERS if L not in LAYERS_PTP]
    # PERFORM PHASE 1 OF HAS-LAYER CREATION TO ENCOUNTER HUBS
    all_hubs = {}  # degrees of the hubs
    cnt_mlt_hubs = 0
    for L in LAYERS_HAS:
        angel_layer_has_mx1(L, edge_size[L])
        hubs = [n for n, h in nx.get_node_attributes(L,'hub').items() if h == 'H']
        for h in hubs:
            if h in all_hubs.keys():
                if  all_hubs[h] < L.degree[h]:
                    all_hubs[h] = L.degree[h]
                    cnt_mlt_hubs += 1
            else :
                all_hubs[h] = L.degree[h]
      
    # CREATE HUB-SUBNETWORK
    # Create a random graph on node size = nbOfHubs using configuration model
    nbOfHubs = len(all_hubs.items())
    hf = 1
    if nbOfLayers < 30: hf = 2
    
    degrees = np.int_(np.random.uniform(1, hf*nbOfHubs, size= nbOfHubs))
    if sum(degrees) % 2 == 1: degrees[0] += 1 # sum of degrees must be an odd number
    H = nx.configuration_model(degrees)
    H_selfloops = list(nx.selfloop_edges(H))
    H.remove_edges_from(H_selfloops)

    # map nodes in H onto hubs and order nodes in H by decreasing degree
    degree_H = dict(H.degree)
    degree_H_ord = collections.OrderedDict(sorted(degree_H.items(), key=lambda t: t[1]))
    degree_all_hubs_ord = collections.OrderedDict(sorted(all_hubs.items(), key=lambda t: t[1]))
    mapping = dict(zip(degree_H_ord.keys(), degree_all_hubs_ord.keys() ) )  # unique_hubs = list(set(all_hubs)))
    H = nx.relabel_nodes(H, mapping)
    
    
    # add hubs as non_hubs to some other layers
    LAYERSH = [L for L in LAYERS_HAS]
    random.shuffle(LAYERSH) 
    for L in LAYERSH:
        hubs = [n for n, h in nx.get_node_attributes(L,'hub').items() if h == 'H']
        for h in hubs :
            neighbors = [n for n in H.neighbors(h)]
            for n in neighbors:
                if not L.has_node(n): 
                    L.add_node(n, pos=GRID[n])
                    L.add_edge(h,n)
                    mf.remove_edge(H,h,n)
           
    """
    Step 3 ADD EDGES TO LAYERS
    """
    for L in LAYERS:
        if L in LAYERS_PTP:
            angel_layer_ptp_mx(L, edge_size[L])
        else:
            # PHASE 2 of has-layer creation
            angel_layer_has_mx2(L, edge_size[L])
        
              
    """
    Step 4 MULTIPLEX
    """
    M = nx.MultiGraph()
    for n in range(nbOfNodes):
        M.add_node(n, pos=GRID[n]) 
    for L in LAYERS: M.add_edges_from(L.edges())
    
    """
    the number of edges might exceed that one given as a parameter
    to keep predicted edge size e.g. for multiplex comparisons
    uncomment the folowing line 
    """
    #mx_remove_edge_overhead(M, LAYERS, nbOfEdges)
        
    return LAYERS, M


"""
sample ANGEL layers as replications of EATN layers
@param: 
    list with reference layers to replicate - simple graph objects
    nbOfSamples - count of replications per layer
@return: 
    DATA - list with lists of nbOfSamples replications per reference layer
"""
def sample_angel_layers(REF_LAYERS, nbOfSamples=100):
    DATA = []
    i=1
    for L in REF_LAYERS:
        print('layer', i)
        sm = nx.smetric.s_metric(L, normalized=False)/(L.number_of_edges()*L.number_of_edges())
        LAYERS = []
        j = 1
        for _ in range(nbOfSamples):
            if mf.set_nb_of_hubs(sm, L.number_of_nodes()/L.number_of_edges()) > 0:
                LAYERS.append(angel_layer_has(L.number_of_nodes(), L.number_of_edges(), nx.get_node_attributes(L,'pos'), sm))
            else:
                LAYERS.append(angel_layer_ptp(L.number_of_nodes(), L.number_of_edges(), nx.get_node_attributes(L,'pos')))
            if j % 10 == 0: print(j)
            j +=1 
        DATA.append(LAYERS) 
        i += 1
    return DATA


"""
sample ANGEL multiplex
@param:
    nbOfSamples - count of replications per layer
@return:
    LSAMPLE - list with lists of nbOfSamples replications per reference layer
    MSALPLE - list with nbOfSamples multiplexes
"""
def sample_angel_multiplex(nbOfSamples=100):
    MSAMPLE = []
    LSAMPLE = []
    for _ in range(nbOfSamples) :
        LAYERS, M = angel_multiplex()
        LSAMPLE.append(LAYERS)
        MSAMPLE.append(M)
        
    return LSAMPLE, MSAMPLE













