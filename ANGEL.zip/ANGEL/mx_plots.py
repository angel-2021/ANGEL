#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
author: Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

plot statistics to a benchmark of multiplexes
'''

import powerlaw
import numpy as np
import networkx as nx
import random
import matplotlib.pyplot as plt
import matplotlib as mpl
import community

import mx_functions as mf
import mx_stats as mxs

ref_color = 'red'
model_name = ['ANGEL','BINBALL', 'STARGEN']
model_color = ['blue', 'green', 'orange']
color_to_model = dict(zip(model_name, model_color))

ref_color = 'black'
model_name = ['ANGEL','BINBALL', 'STARGEN']
model_color = ['darkviolet', 'grey', 'lightseagreen']
model_color_light = ['violet', 'lightgrey', 'paleturquoise']
color_to_model = dict(zip(model_name, model_color))

# layer replication 
syn_name = 'ANGEL'
syn_color = color_to_model[syn_name]

small_plots = True
fontsize = 12
fontsizeTitle=14
fontsizeLabel=14

ref_name = ''  
def setNames(name):
    global ref_name
    ref_name = name
    print('Reference ', ref_name)

fig_prefix = ''
def setFigName(fpre):
    global fig_prefix
    fig_prefix = fpre
    print('Figures', fig_prefix)
    
        
"""
**************************************************************************
**************************************************************************

PLOTS TO COMPARE SINGLE LAYER REPLICATION

per layer of a real network -> nbOfSamples synthetic copies

INPUT: 
    REF_LAYERS - list of layers of real network
    SYN_DATA[i] - list of <nbOfSamples> copies of real layer nb i-1
        
**************************************************************************
**************************************************************************
"""
    
def set_layer_labels(ax):
    labels = ax.get_xticks().tolist()
    xlabelsnew = []
    for i in range(len(labels)) :
        if i in [0, 9, 19, 29] :
            xlabelsnew.append(str(i+1))
        elif i == 37 :
            xlabelsnew.append('M')
        else:
            xlabelsnew.append(' ')
    ax.set_xticklabels(xlabelsnew)
    

    
"""
LAYER TRANSITIVITY, DENSITY and AVERAGE SHORTEST PATH

boxplots with synthetic values and a line with reference values
on density, transitivity, avarage shortest path
"""
def plot_layer_netstats(SYN_DATA):

    syn_trans, syn_dens, syn_asp = mxs.layer_netstats_syn(SYN_DATA)

    fig = plt.figure(figsize=(5, 4))
    
    # TRANSITIVITY + DENSITY
    ax1 = fig.add_subplot(211)
    bp = ax1.boxplot(syn_trans)
    mxs.set_box_color(bp, c1=syn_color, c2=syn_color, c3=syn_color, c4=syn_color)
    plt.setp(bp['fliers'], markeredgecolor=syn_color, marker='+')
    
    y_max = max([max(values) for values in syn_trans])
    y_min = min([min(values) for values in syn_trans])
    ax1.set_ylim(y_min-0.05, 0.4)
    ax1.set_yticks(np.arange(0,y_max, 0.1))
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    plt.setp(ax1.get_xticklabels(), visible=False)
        
    x = range(1, len(SYN_DATA) + 1)
    ax1.set_yticks(np.linspace(0.0,0.4,5))
    ax1.set_ylabel('transitivity', fontsize=fontsizeLabel)
    ax1.set_xticks(x)
    set_layer_labels(ax1)
    plt.legend(loc='upper left',fontsize=fontsize)

    # AVERAGE SHORTEST PATH
    ax2 = fig.add_subplot(212)
    bp = ax2.boxplot(syn_asp)
    mxs.set_box_color(bp, c1=syn_color, c2=syn_color, c3=syn_color, c4=syn_color)
    plt.setp(bp['fliers'], markeredgecolor=syn_color, marker='+')
    x = range(1, len(SYN_DATA) + 1)
    y_max = max([max(values) for values in syn_asp])
    y_min = min([min(values) for values in syn_asp])
    ax2.set_ylim(y_min-0.1, y_max+0.1)
    ax2.set_xticks(x)
    set_layer_labels(ax2)
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    ax2.set_ylabel('average shortest path',fontsize=fontsizeLabel)
    ax2.set_xlabel('layers', fontsize=fontsizeLabel)
    plt.savefig(fig_prefix+'LAYER_network_stats.png', transparent=True)
    plt.show()
    
"""
LAYERS boxplots with s-metric and hub counts, synthetic layers versus reference values 
"""
def plot_layer_smetric_hubcnt(SYN_DATA):
    syn_sm, ref_sm, std_sm = mxs.layer_smetric(SYN_DATA)
    ref_nhubs, syn_nhubs, std_nhubs = mxs.layer_hubcnt(SYN_DATA)
    
    fig = plt.figure(figsize=(5, 4))
    ax1 = fig.add_subplot(211)
    bp = ax1.boxplot(syn_sm)
    mxs.set_box_color(bp, c1=syn_color, c2=syn_color, c3=syn_color, c4=syn_color)
    plt.setp(bp['fliers'], markeredgecolor=syn_color, marker='+')
    x = range(1, len(SYN_DATA) + 1)
    ax1.plot(x, ref_sm, syn_color, linewidth=1, label=syn_name)
    ax1.plot(x, ref_sm, ref_color, linewidth=1, label=ref_name)
    plt.setp(ax1.get_xticklabels(), visible=False)
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    ax1.set_xticks(x)    
    set_layer_labels(ax1)
    ax1.set_ylabel('s-metric', fontsize=fontsizeLabel)
    plt.legend(loc='lower right', fontsize=fontsize)
            
    ax2 = fig.add_subplot(212)
    bp = ax2.boxplot(syn_nhubs)
    mxs.set_box_color(bp, c1=syn_color, c2=syn_color, c3=syn_color, c4=syn_color)
    plt.setp(bp['fliers'], markeredgecolor=syn_color, marker='+')
    ax2.scatter(x, ref_nhubs, color=syn_color, marker='o', facecolors='none', s=10, label=syn_name)
    ax2.scatter(x, ref_nhubs, color=ref_color, marker='o', facecolors='none', s=10, label=ref_name)
    y_max = max(max([max(values) for values in syn_nhubs]), max(ref_nhubs))
    y_min = min(min([min(values) for values in syn_nhubs]), min(ref_nhubs))
    ax2.set_ylim(y_min-.5, y_max+.5)
    ax2.set_yticks(np.arange(y_min, y_max+1, 1))
    ax2.set_xticks(x)
    set_layer_labels(ax2)
    ax2.set_xlabel('layers',fontsize=fontsizeLabel)
    ax2.set_ylabel('number of hubs',fontsize=fontsizeLabel)
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)
        
    mxs.chi_quadrat(ref_nhubs, syn_nhubs)
    
    plt.savefig(fig_prefix+'LAYER_smetrics.png', transparent=True)
    plt.show()
    


       
        
"""
compare assortivity coefficient of layer replicas and multiplex 
"""

def plot_assortivity_coeff(SYN_LAYERS, MODELS_SAMPLE, model):
    syn = []
    for LAYERS in SYN_LAYERS:
        syn.append([mxs.assortivity_coef(L) for L in LAYERS])
    syn_mx = []
    for LAYER_SET in MODELS_SAMPLE[model]:
        M = mxs.create_multiplex(LAYER_SET)
        syn_mx.append(mxs.assortivity_coef(M))
    syn.append(syn_mx)
   
    fig = plt.figure(figsize = (5, 5))    
    ax = fig.add_subplot(111)
    bp = ax.boxplot(syn)
    color = color_to_model[model]
    mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
    ax.tick_params(axis='both', which='major', labelsize=fontsize)  
    set_layer_labels(ax)
    ax.set_xlabel('layers and multiplex', fontsize=fontsizeLabel)
    ax.set_ylabel('degree assortativity coefficient', fontsize=fontsizeLabel)
    plt.legend(loc='upper left', fontsize=fontsize)
    plt.savefig(fig_prefix+'assortativity.png', transparent=True, bbox_inches="tight")
    plt.show()
    


"""
compare assortivity coefficient of layer replicas and multiplex 
"""

def plot_coreness(values, model):
    mxs.sort_by_median0(values)  # except mx
   
    fig = plt.figure(figsize = (5, 5))    
    ax = fig.add_subplot(111)
    bp = ax.boxplot(values)
    color = color_to_model[model]
    mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
    #x = [n+1 for n in range(nbOfLayers+1)] #plus mx
    ax.tick_params(axis='both', which='major', labelsize=fontsize)  
    set_layer_labels(ax)
    ax.set_xlabel('layers and multiplex', fontsize=fontsizeLabel)
    ax.set_ylabel('coreness correlation ANGEL versus EATN', fontsize=fontsizeLabel)
    #plt.legend(loc='upper left', fontsize=fontsize)
    plt.savefig(fig_prefix+'coreness.png', transparent=True, bbox_inches="tight")
    plt.show()

           
    
"""
**************************************************************************
**************************************************************************

PLOTS TO COMPARE REAL NETWORK AND SYNTHETIC MULTIPLEX DATA SETS

real and synthetic network must have the same node, edge and layer size
synthetic data sets have equal nb of samples

INPUT: 
    REF_LAYERS - list of layers of real network
    MODELS_SAMPLE[i][j]
        j-th sample of layers of one synthetic multiplex of the model i
   
**************************************************************************
**************************************************************************
"""

"""
MULTIPLEX DEGREE DISTRIBUTION
"""   

def plot_compare_mx_degree(MODELS_SAMPLE, ax1, ax2, plot_all=False):
    
    nbOfNodes = mxs.MX_NODE_CNT
    
    min_deg = []
    max_deg = []
    for model, LAYERS in MODELS_SAMPLE.items():    
        for LAYER_SET in LAYERS:
            MX = mxs.create_multiplex(LAYER_SET)
            deg_val = sorted([MX.degree[k] for k in MX.nodes])
            min_deg.append(min(deg_val))
            max_deg.append(max(deg_val))
 
        av_degree_values = mxs.subplot_mx_degree(ax1, ax2, nbOfNodes, LAYERS,
                                                 color_to_model[model], plot_all)
      
        ax1.hist( av_degree_values, nbOfNodes, density=True, stacked=True,
             histtype='step', cumulative=-1, color=color_to_model[model], linewidth=2)
        ax2.hist( av_degree_values, nbOfNodes, density=True, stacked=True,
             histtype='step', cumulative=-1, color=color_to_model[model], log =True,
             label=model , linewidth=2)
        
        min_x = min(av_degree_values)
        max_x = max(av_degree_values)
  
    min_x = int(min_x)
    max_x = int(max_x) + 10
    
    x = np.array(range(min_x, max_x))
    plFit = powerlaw.Fit(np.trim_zeros(np.array(sorted(av_degree_values))), discrete =True)
    alpha = plFit.alpha
    xmin = plFit.xmin
    y = pow(x/xmin, 1-alpha) - 0.06 
    
    label = 'power law'
    if small_plots:
        label = 'power'
        ax1.tick_params(axis='both', which='major', labelsize=fontsize)
        ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    
    ax1.plot(x, y, color='black', alpha=0.6)
    ax2.plot(x, y, color='black', label=label, alpha=0.6)
 
    for ax in [ax1, ax2]:
        ax.set_xlabel('k', fontsize=fontsizeLabel)
        ax.set_ylabel('P(degree > k)', fontsize=fontsizeLabel)
        ax.set_xlim(-0.5, max_x) 
    ax1.set_ylim(-0.05, 1.05)
    ax2.set_ylim(0.001, 1.05)
    ax2.legend(loc='lower left', fontsize=fontsize)



"""
MULTIPLEX: AVERAGE SHORTEST PATH AND CENTRALITY PER NODE
"""

def plot_compare_mx_sp_cc(MODELS_SAMPLE, ax1, ax2, plot_all):
    
    for model, LAYERS in  MODELS_SAMPLE.items():
        REF_MX = mxs.create_multiplex(LAYERS[0])
        # calculate values, plot for each sample and return average
        
        av_asp, av_cc = mxs.subplot_mx_sp_cc(ax1, ax2, REF_MX.number_of_nodes(),
                                                LAYERS, color_to_model[model], model, plot_all)      
        ax1.plot( av_asp, color=color_to_model[model], label=model)
        ax2.plot( av_cc, color=color_to_model[model])
            #ax1.set_yscale('log')
            #ax2.set_yscale('log')
        min_a = min(av_asp)
        min_c = min(av_cc)
        max_a = max(av_asp)
        max_c = max(av_cc)
            
    min_a = int(min_a)
    max_a = int(max_a)+1
    min_c = int(min_c*10)
    max_c = int((max_c)*10)+1

    ax1.set_ylabel('avg shortest path', fontsize=fontsizeLabel)
    ax1.set_xlabel('nodes', fontsize=fontsizeLabel)
    ax1.set_ylim(min_a, max_a)
    ax1.set_yticks(np.linspace(min_a, max_a, max_a-min_a+1 ))
    plt.setp(ax1.get_xticklabels(), visible=False)
    plt.setp(ax1.get_xticklines(), visible=False)
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    ax1.legend(loc='upper left', fontsize=fontsize)
    ax2.set_ylabel('node centrality', fontsize=fontsizeLabel)
    ax2.set_xlabel('nodes', fontsize=fontsizeLabel)
    ax2.set_ylim(min_c*.1-0.05, max_c*.1+0.05)
    ax2.set_yticks(np.linspace(min_c*.1, max_c*.1, max_c-min_c+1 ))
    plt.setp(ax2.get_xticklabels(), visible=False)
    plt.setp(ax2.get_xticklines(), visible=False)
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    
    
     
"""
STATISTICS ON MULTIPLEX AS ONE NETWORK, MULTI- AND SIMPLE GRAPH
density, transitivity, average shortest path, betweenness
"""
def plot_compare_mx_stats(MODELS_SAMPLE, ax):
    for axs in ax:
        axs.tick_params(axis='both', which='major', labelsize=fontsizeLabel)

    # BOXPLOTS
    box_width = 0.5
    pos = [0.8, 1.8, 2.8]

    for model, LAYERS in MODELS_SAMPLE.items():
        dens, trans, asp, bet = mxs.network_statisctics(LAYERS, False)
        
        # DENSITY BOXPLOT 
        dens.append(trans)
        bp = ax[0].boxplot(dens, widths=box_width, positions=pos)
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
        plt.setp(bp['fliers'], markeredgecolor=color, marker='+')
        
        # AVERAGE SHORTEST PATH BOXPLOT
        bp = ax[1].boxplot(asp, widths=box_width, positions=[pos[0]])
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
        plt.setp(bp['fliers'], markeredgecolor=color, marker='+')

        # BETWEENNESS BOXPLOTS
        bp = ax[2].boxplot(bet, widths=box_width, positions=[pos[0]])
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
        plt.setp(bp['fliers'], markeredgecolor=color, marker='+')

        pos[0] += 0.2
        pos[1] += 0.2
        pos[2] += 0.2
        
        vals = [dens[0], dens[1], trans, asp, bet]
   
    rot = 0
    labelsden = ['density (m)', 'density (s)', 'transitivity']
    labelasp = ['avg shortest path']
    labelbc = ['betweenness centr.']
    if small_plots:
        rot = 0
        labelsden = ['den_m', 'den_s', 'trans']
        labelasp = ['avg sp']
        labelbc = ['bt cen']
    
    ax[0].set_xticks([1.,2.,3.])
    ax[0].set_xlim(0.5,3.5)
    ax[0].set_xticklabels(labels=labelsden, rotation=rot)
    ax[0].set_yticks(np.linspace(0,0.4,5))
    ax[0].legend(loc='upper left', fontsize=fontsize)
    #ax[0].tick_params(axis='x', which='major', pad=-5)
    
    # AVERAGE SHORTEST PATH BOXPLOT
    ax[1].set_xticks([1])
    ax[1].set_xticklabels(labelasp)
    ax[1].tick_params(axis='x', which='major', labelsize=fontsizeLabel)
    ax[1].xaxis.set_tick_params(labelsize=fontsizeLabel)
    ax[1].set_xlim(0.,4.)
    ax[1].set_yticks(np.linspace(2.5,2.8,4))
    
    # BETWEENNESS BOXPLOTS
    ax[2].set_xticks([1])
    ax[2].set_xticklabels(labelbc)
    ax[2].tick_params(axis='x', which='major', labelsize=fontsizeLabel)
    ax[2].set_xlim(0.5,1.5)
    ax[2].yaxis.tick_right()
    ax[2].set_yticks(np.linspace(0.003,0.005,3))
    
    for axs in ax:
        axs.tick_params(axis='both', which='major', labelsize=fontsize)
    
        
"""
LAYER NODE AND EDGE SIZES
""" 
def plot_compare_layer_sizesCOMPACT(MODELS_SAMPLE, ax1, ax2, plot_all):

    # NODE SIZES
    min_value = 100
    max_value = 0
    for model, LAYERS in MODELS_SAMPLE.items():
        nbOfLayers = len(LAYERS[0])
        av_values = mxs.subplot_layer_sizes(ax1, LAYERS, color_to_model[model], True, plot_all)
        ax1.hist(av_values, nbOfLayers, density=True, stacked=True, histtype='step', cumulative=-1, log=True,
             color=color_to_model[model], linewidth =2., label=model) 
        min_value = min(min_value, min(av_values))
        max_value = max(max_value, max(av_values))
    
    # axis    
    x_max = max_value
    x_min = min_value
    x_min = int(x_min*0.1)*10
    x_max = (int(x_max*0.1) + 1) *10
    ax1.set_xlim(x_min, x_max + 5)
    ax1.set_xticks(range(x_min, x_max, 20))
    ax1.set_xlabel('k', fontsize=fontsizeLabel)
    ax1.set_ylabel('P(nodes > k)', fontsize=fontsizeLabel)
    ax1.set_ylim(0.009, 1.15)
    
    # EDGE SIZES
    for model, LAYERS in MODELS_SAMPLE.items():
        av_values = mxs.subplot_layer_sizes(ax2, LAYERS, color_to_model[model], False, plot_all)
        ax2.hist(av_values, nbOfLayers, density=True, stacked=True, histtype='step', cumulative=-1, 
             color=color_to_model[model], linewidth =2., label=model) 
        min_value = min(min_value, min(av_values))
        max_value = max(max_value, max(av_values))
        
    x_max = max_value
    x_min = min_value
    x_min = int(x_min*0.1)*10
    x_max = (int(x_max*0.1) + 1) *10
    ax2.set_xlim(x_min-10, x_max+10)
    ax2.set_xticks(range(50, x_max, 100))
    ax2.set_ylabel('P(edges > k)', fontsize=fontsizeLabel) #, log scale', labelpad=-12)
    ax2.xaxis.tick_top()
    ax2.set_ylim(.009, 1.15)
    
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)




"""
LAYER REPETITION HISTOGRAM
""" 
def plot_compare_layer_repetition(MODELS_SAMPLE, ax, node_set, plot_all): #, legend=False):
    
    for model, LAYERS in MODELS_SAMPLE.items():
        nbOfLayers = len(LAYERS[0])
        ave_rep = mxs.subplot_layer_repetition(node_set, 
            LAYERS, ax, color_to_model[model], plot_all)
        ax.hist( ave_rep, nbOfLayers, density=True, stacked=True, histtype='step', 
                 cumulative=-1, color=color_to_model[model], 
                 linewidth=2., log =True, label=model)  
    
    label = 'P(layer repetition cnt '+ node_set +')> k)'
    if small_plots:
        label = 'P('+node_set+')> k)'
    ax.set_ylabel(label, fontsize=fontsizeLabel)
    if node_set =='non-hub':
        #ax.tick_params(labelbottom=False) 
        ax.set_ylim(0.0005,1.3)
    else:
        ax.set_xlabel('k', fontsize=fontsizeLabel)
        ax.set_ylim(0.005,1.3)
        ax.yaxis.tick_right()
    ax.set_xlim(-0.5,nbOfLayers+0.5)
    ax.set_xticks(range(1,nbOfLayers+1, 5))
    ax.tick_params(axis='both', which='major', labelsize=fontsize)
    


    
        
"""
LAYER NODE AND EDGE SIZES
""" 
def plot_compare_layer_sizes(MODELS_SAMPLE, ax1, ax2, plot_all):

    # NODE SIZES
    min_value = 100
    max_value = 0
    for model, LAYERS in MODELS_SAMPLE.items():
        nbOfLayers = len(LAYERS[0])
        av_values = mxs.subplot_layer_sizes(ax1, LAYERS, color_to_model[model], True, plot_all)
        ax1.hist(av_values, nbOfLayers, density=True, stacked=True, histtype='step', cumulative=-1, 
             color=color_to_model[model], linewidth =2., label=model) 
        min_value = min(min_value, min(av_values))
        max_value = max(max_value, max(av_values))
    
    # axis    
    x_max = max_value
    x_min = min_value
    x_min = int(x_min*0.1)*10
    x_max = (int(x_max*0.1) + 1) *10
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    ax1.set_xlim(x_min, x_max)
    ax1.set_xticks(range(x_min, x_max, 20))
    ax1.set_xlabel('k', fontsize=fontsizeLabel)
    ax1.set_ylabel('P(node size > k)', fontsize=fontsizeLabel)
    ax1.set_ylim(-0.05, 1.05)
    #ax1.legend(loc='upper right', fontsize=fontsize)
    
    # EDGE SIZES
    for model, LAYERS in MODELS_SAMPLE.items():
        av_values = mxs.subplot_layer_sizes(ax2, LAYERS, color_to_model[model], False, plot_all)
        ax2.hist(av_values, nbOfLayers, density=True, stacked=True, histtype='step', cumulative=-1, 
             color=color_to_model[model], linewidth =2., label=model) 
        min_value = min(min_value, min(av_values))
        max_value = max(max_value, max(av_values))

    x_max = max_value
    x_min = min_value
    x_min = int(x_min*0.1)*10
    x_max = (int(x_max*0.1) + 1) *10
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    ax2.set_xlim(x_min, x_max)
    ax2.set_xticks(range(50, x_max, 100))
    ax2.set_ylabel('P(edge size > k)', fontsize=fontsizeLabel) #, log scale', labelpad=-12)
    ax2.set_xlabel('k', fontsize=fontsizeLabel)
    ax2.set_ylim(-0.05, 1.05)

    
"""
HUBS NETWORK
"""    

def plot_compare_hubnet_degree(MODELS_SAMPLE, ax1, ax2, plot_all):    
    max_val_S = 0
    max_val_M = 0
    for model, LAYERS in MODELS_SAMPLE.items():
        all_vals_list_S, all_vals_list_M = mxs.subplot_hubnet_degree(
            ax1, ax2, LAYERS, color_to_model[model], model, plot_all)
        # averages
        cum = -1
        if len(all_vals_list_S) > 0:
            ax1.hist( all_vals_list_S, len(all_vals_list_S), density=True, stacked=True, 
                     histtype='step', cumulative=cum, log=True, 
                     linewidth=2., color=color_to_model[model], label=model)
            ax2.hist( all_vals_list_M, len(all_vals_list_M), density=True, stacked=True, 
                     histtype='step', cumulative=cum,  
                     linewidth=2., color=color_to_model[model], log =True, label=model)
            max_val_S = max(max_val_S, max(all_vals_list_S))
            max_val_M = max(max_val_M, max(all_vals_list_M))
        
    
    # axis description
    ax1.set_xlabel('k', fontsize=fontsizeLabel, labelpad=-2)
    ax1.set_xlim(-1, max_val_S+1)
    #ax1.set_xticks(range(0, max_val_S+5, 10))
    ax1.set_ylim(0.0001,1.2)
    ax1.text(8, 0.0002, 'simple graph', bbox=dict(facecolor='none', edgecolor='black'), fontsize=fontsize)
    ylabel = 'P(degree > k)'
    if small_plots:
        plt.setp(ax1.get_yticklabels(), visible=False)
        ax1.tick_params(axis='both', which='major', labelsize=fontsize)
        ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    
    ax2.set_xlabel('k', fontsize=fontsizeLabel, labelpad=-2)
    ax2.set_ylabel(ylabel, fontsize=fontsizeLabel)
    ax2.set_ylim(0.0001,1.2)
    ax2.set_xlim(-5, max_val_M+2)
    #ax2.set_xticks(range(0, max(max_val_M+5, 20)))
    ax2.text(10, 0.0002, 'multigraph', bbox=dict(facecolor='none', edgecolor='black'), fontsize=fontsize)

    
"""
BOXPLOT ON HUB COUNTS
"""
def plot_compare_hub_counts(MODELS_SAMPLE, ax):
    box_width = 0.3
    pos = {}
    pos['ANGEL'] = [0.8, 1.8]
    pos['BINBALL'] = [1,2]
    pos['STARGEN'] = [1.2, 2.2]
        
    for model, LAYERS in MODELS_SAMPLE.items():
        data = [[] for _ in range(2)]
        for L in LAYERS:
            hubs = mf.hubs_multiplex(L)
            data[0].append(len(list(set(hubs))))
            data[1].append(len(hubs))
        bp = ax.boxplot(data, widths=box_width, positions=pos[model])
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
    
    ax.set_xticks([1.,2.])
    yrange = np.linspace(0,60,7)
    rot = 0
    labels = ['unique', 'repeated']
    if small_plots:
        rot = 20
        ax.tick_params(axis='both', which='major', labelsize=fontsize)
    ax.set_xticklabels(labels, rotation=rot)
    ax.set_xlim(0.5,2.5)
    ax.set_yticks(yrange)
    ax.set_ylabel('total hub count', fontsize=fontsizeLabel)
    
    
"""
HUB SUBNETWORK boxplots with density, transitivity, asp, and betweenness centrality
"""
def plot_compare_hubnet_stats(MODELS_SAMPLE, ax_dens, ax_trans):
    
    # BOXPLOTS
    box_width = 0.2
    pos = [0.8, 1.8]
    for model, LAYERS in MODELS_SAMPLE.items():
        dens, trans, asp, bet = mxs.network_statisctics(LAYERS, True)
        
        if len(trans) > 0: # the hub-sub-network is not empty        
            # DENSITY BOXPLOT 
            bp = ax_dens.boxplot(dens, widths=box_width, positions=pos)
            color = color_to_model[model]
            mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
            plt.setp(bp['fliers'], markeredgecolor=color, marker='+')
            
            # TRANSITIVITY BOXPLOT
            bp = ax_trans.boxplot(trans, widths=box_width, positions=[pos[0]])
            color = color_to_model[model]
            mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
            plt.setp(bp['fliers'], markeredgecolor=color, marker='+')
            pos[0] += 0.2
            pos[1] += 0.2
         
    # DENSITY AXIS
    ax_dens.set_xticks([0.9,2.1])
    ax_dens.set_xticklabels(['multigraph', 'simple graph'])
    ax_dens.set_ylabel('density')
    ax_dens.legend(loc='upper right')
    ax_dens.set_xlim(0.5,2.5)
    
    # TRANSITIVITY AXISs
    ax_trans.set_xticks([1])
    xticks_labels = ['simple graph']
    ax_trans.set_xticklabels(xticks_labels)
    ax_trans.set_ylabel('transitivity')
    ax_trans.set_yticks(np.linspace(0.0,1.0,6))
    ax_trans.set_xlim(0.5,1.5)
    
    

"""
MULTIPLEX DEGREE GROUPS IN LAYERS
"""
def plot_compare_layer_degree(MODELS_SAMPLE):
    grid_col_nb = len(MODELS_SAMPLE.keys()) + 2
    width_ratios =[ 4 for _ in range(1,grid_col_nb)]
    width_ratios.append(0.5)
    
    from matplotlib import gridspec
    gs = gridspec.GridSpec(1, grid_col_nb, width_ratios=width_ratios) 
    #gs.update(wspace=0.1)
    axs = [plt.subplot(gs[i]) for i in range(grid_col_nb) ]
     
    colormap = plt.cm.get_cmap("Paired",11) # colormap
    bar_width = 1.0
     
    k = 0
    for model, LAYERS in MODELS_SAMPLE.items():
        LAYERS_RAND = random.choice(LAYERS)
        data_cnt_ex = mxs.layer_degree_groups_count(LAYERS_RAND)
   
        x = range(len(LAYERS[0]))
        for i in reversed(range(11)):
            nb = i*10
            axs[k].bar(x, data_cnt_ex["c"+str(nb)], bar_width, color=colormap(i))
        #axs[k].set_title(model)
        axs[k].text(len(LAYERS_RAND)/2-5, 0.1, model, bbox=dict(facecolor='none', edgecolor='black'), fontsize=fontsize)
        k += 1
        
    axs[0].set_ylabel('% nodes', fontsize=fontsizeLabel)
    axs[0].set_yticks([0.2, 0.4, 0.6, 0.8, 1.])
    axs[0].set_yticklabels(['20', '40', '60', '80', '100'], fontsize=fontsize)
    axs[0].set_ylim(0, 1.05)    

    # colorbar
    bounds = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    norm = mpl.colors.BoundaryNorm(bounds, ncolors=11)
    cb = mpl.colorbar.ColorbarBase(axs[k+1], 
                                    cmap=colormap,
                                    norm=norm,
                                    orientation='vertical',
                                    ticks=bounds,  # optional
                                    spacing='proportional')
    cb.set_ticks(np.linspace(0.5, 10.5, num=11))
    labels = ['deg=1', '<10', '<20', '<30','<40', '<50', '<60','<70', '<80', '<90','<100']
    cb.set_ticklabels(labels)
    cb.ax.tick_params(labelsize=fontsize) 
    cb.set_label('% of max degree', fontsize=fontsizeLabel)
    
    plt.setp(axs[0].get_xticklabels(), visible=False)
    plt.setp(axs[0].get_xticklines(), visible=False)
    for i in range(1,k+1):
        plt.setp(axs[i].get_xticklabels(), visible=False)
        plt.setp(axs[i].get_xticklines(), visible=False)
        plt.setp(axs[i].get_yticklabels(), visible=False)
        plt.setp(axs[i].get_yticklines(), visible=False)
        axs[i].set_ylim(0, 1.05)
        axs[i].set_xlabel('layers', fontsize=fontsizeLabel)  
    axs[0].set_xlabel('layers', fontsize=fontsizeLabel) 
    
    
 
"""
layer  intersection:one example per model
"""
    
def plot_compare_layer_intersection(MODELS_SAMPLE, settings):
    
    ref_name, ref_color, color_to_model, fig_prefix = settings
    
    plt.subplots_adjust(left=None, bottom=0.3, right=None, top=0.7,
                wspace=0.06, hspace=0.5)
    r = 1
    c = 3
    i = 0
    for model, LSET in MODELS_SAMPLE.items():
        ax = plt.subplot2grid((r,c), (0,i))
        i += 1
        LAYERS = random.choice(LSET)
        layer_prc, _ = mxs.get_intersection_data(LAYERS)        
        bp = ax.boxplot(layer_prc, vert=True, patch_artist=True, showfliers=False)
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4='black')
        ax.text(3, 80, model, bbox=dict(facecolor='none', edgecolor=color), fontsize=fontsize)
        ax.set_xlabel('layers', fontsize=fontsizeLabel)
        if i == 1:
            ax.set_ylabel('% of nodes', fontsize=fontsizeLabel)
        ax.set_ylim(-1,100)
        plt.setp(ax.get_xticklabels(), visible=False)
        plt.setp(ax.get_xticklines(), visible=False)
        if i > 1:
            plt.setp(ax.get_yticklabels(), visible=False)
            plt.setp(ax.get_yticklines(), visible=False)
        else:
            plt.tick_params(axis='both', which='major', labelsize=fontsize)
             

       
        
"""
BOXPLOTS WITH S-METRIC IN LAYERS PER MODEL
"""
def plot_compare_smetric(MODELS_SAMPLE, ax):
    box_width = 0.1
    pos = 0.8
    labels = []
    for model, LAYERSET in MODELS_SAMPLE.items():
        sm = []
        for LAYERS in LAYERSET:
            for L in LAYERS:
                n = L.number_of_edges()
                sm.append(nx.smetric.s_metric(L, normalized=False)/(n*n))
        bp = ax.boxplot(sm, widths=box_width, positions=[pos])
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
        plt.setp(bp['fliers'], markeredgecolor=color, marker='+')
        pos += 0.15
        labels.append(model)
        
    plt.tick_params(axis='both', which='major', labelsize=fontsize)
    ax.set_xticks([0.8, 0.95, 1.1])
    ax.set_xlim(0.7,1.2)
    ax.set_yticks(np.linspace(0.1,1.1,6))
    ax.set_ylim(0,1.2)
    ax.set_xticklabels(labels, rotation = 35, fontsize=10)
    ax.set_ylabel('s-metric per layer', fontsize=fontsizeLabel)
    
      
"""
plot cosine similarity : Matrix plot

"""
def plot_compare_cos_sim(LAYERS1, LAYERS2, name1, name2, ax):     
    cs, cmStats = mxs.cosine_similarity(LAYERS2, LAYERS1)

    ms = ax.matshow(cs, interpolation='bilinear', cmap='binary')
    ax.tick_params(axis='both', which='major', labelsize=fontsize)
    ax.text(15, 395, name1, bbox=dict(facecolor='none', edgecolor='black'), fontsize=fontsize)
    ax.text(315, 35, name2, bbox=dict(facecolor='none', edgecolor='black'), fontsize=fontsize)
    cb = plt.colorbar(ms, fraction=0.045, pad=0.05, ax=ax)
    cb.ax.tick_params(labelsize=fontsize)
    
"""
COMMUNITIES IN MULTIPLEX
"""
def plot_communities(LAYERS_REF, LAYERSET, model):
    M_REF = mxs.create_multiplex(LAYERS_REF)
    ref_values = []
    partition = community.best_partition(M_REF)
    com_cnt = float(len(set(partition.values())))
    ref_values.append(com_cnt)
    node_nb = []
    layer_nb = []
    for com in set(partition.values()) :
        list_nodes = [nodes for nodes in partition.keys() if partition[nodes] == com]
        if len(list_nodes) > 1:
            node_nb.append(len(list_nodes))
            CLAY = []
            for L in LAYERS_REF:
                for node in list_nodes:
                    if node in L.nodes():
                        CLAY.append(L)
            layer_nb.append(len(set(CLAY)))
    ref_values.append(min(node_nb))
    ref_values.append(int(sum(node_nb)/len(node_nb)))
    ref_values.append(max(node_nb))
    ref_values.append(min(layer_nb))
    ref_values.append(int(sum(layer_nb)/len(layer_nb)))
    ref_values.append(max(layer_nb))

    
    cnt = []
    min_node_nb = []
    mean_node_nb = []
    max_node_nb = []
    min_l_nb = []
    mean_l_nb = []
    max_l_nb = []
    for LAYERS in LAYERSET:
        M = mxs.create_multiplex(LAYERS)
        partition = community.best_partition(M)
        com_cnt = float(len(set(partition.values())))
        cnt.append(com_cnt)
        node_nb = []
        layer_nb = []
        for com in set(partition.values()) :
            list_nodes = [nodes for nodes in partition.keys() if partition[nodes] == com]
            if len(list_nodes) > 1:
                node_nb.append(len(list_nodes))
                CLAY = []
                for L in LAYERS:
                    for node in list_nodes:
                        if node in L.nodes():
                            CLAY.append(L)
                layer_nb.append(len(set(CLAY)))
                
        min_node_nb.append(min(node_nb))
        mean_node_nb.append(int(sum(node_nb)/len(node_nb)))
        max_node_nb.append(max(node_nb))
        min_l_nb.append(min(layer_nb))
        mean_l_nb.append(int(sum(layer_nb)/len(layer_nb)))
        max_l_nb.append(max(layer_nb))
        
    data = [cnt, min_node_nb, mean_node_nb, max_node_nb, min_l_nb, mean_l_nb, max_l_nb]  
    
    fig = plt.figure(figsize = (10, 5))    
    ax = fig.add_subplot(111)
    bp = ax.boxplot(data, zorder=0)
    color = color_to_model[model]
    mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
    x = [n+1 for n in range(len(ref_values))]
    ax.scatter(x, ref_values, marker='o', s=8, color=color_to_model[model], label=model, zorder=5)
    ax.scatter(x, ref_values, marker='o', s=10, color=ref_color, label=ref_name, zorder=10)
    ax.tick_params(axis='both', which='major', labelsize=fontsize)  
    ax.set_xticklabels(['com. count', 'min node cnt.', 'mean node cnt.', 'max node cnt.', 'min layer cnt.', 'mean layer cnt.', 'max layer cnt.'], rotation=20)
    plt.legend(loc='upper left', fontsize=fontsize)
    plt.savefig(fig_prefix+'communities.png', transparent=True, bbox_inches="tight")
    plt.show()
    
    
"""
running times
"""
def plot_runtimes(data, posvals, ax, ref_name):
    global fontsize
    fontsize = 12
    global fontsizeLabel
    fontsizeLabel = 14
 
    box_width = 0.05
    
    positions = [p-0.05 for p in posvals.keys()]
    ymax = 0
    lines = []
    models = []
    
    for model, vals in data.items():
        bp = ax.boxplot(vals,  positions=positions, widths=box_width)
        color = color_to_model[model]
        mxs.set_box_color(bp, c1=color, c2=color, c3=color, c4=color)
        plt.setp(bp['fliers'], markeredgecolor=color, marker='+')
        
        # connect medians
        yvals = [] 
        for line in bp['medians']:
            _, y = line.get_xydata()[1] 
            yvals.append(y)
        ax.plot(positions, yvals, color=color, ls='-.', lw=.5) #, label=model)
        positions = [p+0.05 for p in positions]
        ymax = max(ymax, max([max(v) for v in vals]))

        line, = ax.plot([1,1], ls= '-', color=color, lw=2)
        lines.append(line)
        models.append(model)
    
    #line_ref, = plt.plot([1,1], ls= '-', color='white', lw=2)
    
    ax.set_title(ref_name) 
    ax.tick_params(axis='both', which='major', labelsize=fontsize)
    ymax = int(ymax/10)*10 +10
    ax.set_ylim(0, ymax +1)
    if ref_name == 'EATN':
        ax.set_ylabel('time in sec.', fontsize=fontsizeLabel)  
        ax.legend((lines[0], lines[1], lines[2]),(models[0], models[1], models[2]), 
                  loc='upper left', fontsize=fontsize)
    for l in lines:
        l.set_visible(False)
    ax.set_xlim(0.,max([p for p in posvals.keys()])+0.15 ) 
    # xlabels
    if ref_name == 'EATN':
        xticks = [0.]
        xticks.extend([p for p in posvals.keys()] )
        labels = ['#layers\n#nodes\n#edges']
        labels.extend(['\n'.join(map(str, labs)) for labs in posvals.values()])
    else:
        xticks = [p for p in posvals.keys()]
        labels = ['\n'.join(map(str, labs)) for labs in posvals.values()]
    ax.set_xticks(xticks)
    ax.set_xticklabels(labels, fontsize=fontsize)     
    
    
"""
print all plots for MX statistics with all models
"""
def plot_stats_all(MODELS_SAMPLE, plot_all=False):
    global fontsize
    fontsize = 10
    global small_plots
    small_plots = False

    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    
    degree, netstats, sizes, rep, hubdeg, hubnet, sm, rest = [True, True, True, True, True, True, True, True]
    
    # MULTIPLEX degree
    if degree:
        fig = plt.figure(figsize = (10, 6))
        ax_m = fig.add_subplot(111)
        ax_mlog = inset_axes(ax_m, width="65%", height="65%", loc=1)
        plot_compare_mx_degree(MODELS_SAMPLE, ax_m, ax_mlog, plot_all)
        plt.savefig(fig_prefix+'MX_degree.png')
        plt.show()
      
    # MULTIPLEX statistics
    if netstats:
        plt.figure(figsize = (10, 6))
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                    wspace=0.4, hspace=.2)
        r = 2
        c = 4
        ax_stp =  plt.subplot2grid((r,c), (0,0), colspan=2)
        ax_cc = plt.subplot2grid((r,c), (0,2), colspan=2)
        ax_bp = []
        ax_bp.append(plt.subplot2grid((r,c), (1,0), colspan=2))
        ax_bp.append(plt.subplot2grid((r,c), (1,2), colspan=1))
        ax_bp.append(plt.subplot2grid((r,c), (1,3), colspan=1))
        plot_compare_mx_sp_cc(MODELS_SAMPLE, ax_stp, ax_cc, plot_all)
        plot_compare_mx_stats(MODELS_SAMPLE, ax_bp)
        ax_bp[0].set_xticklabels(['density (m)', 'density (s)', 'transitivity'])
        ax_bp[0].set_xlim(0,4)
        ax_bp[0].tick_params(axis='x', which='major', pad=5)
        plt.savefig(fig_prefix+'MX_netStats.png')
        plt.show()
          
    # LAYER sizes 
    if sizes:
        fig = plt.figure(figsize = (10, 6))
        ax_sizeE = fig.add_subplot(111)
        ax_sizeN = inset_axes(ax_sizeE, width="65%", height="65%", loc=1)
        plot_compare_layer_sizes(MODELS_SAMPLE, ax_sizeN, ax_sizeE, plot_all)
        plt.savefig(fig_prefix+'MX_layerSize.png')
        plt.show()
     
    # LAYER repetition counts 
    if rep:
        fig = plt.figure(figsize = (10, 6))
        ax_nhub_lrc = fig.add_subplot(111)
        ax_hub_lrc = inset_axes(ax_nhub_lrc, width="65%", height="65%", loc=1)
        plot_compare_layer_repetition(MODELS_SAMPLE, ax_nhub_lrc, 'non-hub', plot_all)
        plot_compare_layer_repetition(MODELS_SAMPLE, ax_hub_lrc, 'hub', plot_all) 
        plt.savefig(fig_prefix+'MX_layerRep.png')
        plt.show()
    
    # HUBS degree
    if hubdeg:
        fig = plt.figure(figsize = (10, 6))
        ax_degM = fig.add_subplot(111)
        ax_degS = inset_axes(ax_degM, width="40%", height="55%", loc=1)
        plot_compare_hubnet_degree(MODELS_SAMPLE, ax_degS, ax_degM, plot_all)
        plt.savefig(fig_prefix+'MX_hubsDegree.png')
        plt.show()
    
    # HUBS network statistics
    if hubnet:
        plt.figure(figsize = (10, 4))
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                    wspace=1., hspace=0.3)
        r = 1
        c = 5
        ax_dens = plt.subplot2grid((r,c), (0,0), colspan=2)
        ax_trans = plt.subplot2grid((r,c), (0,2), colspan=1)
        ax_size = plt.subplot2grid((r,c), (0,3), colspan=2)   
        plot_compare_hub_counts(MODELS_SAMPLE, ax_size)
        plot_compare_hubnet_stats(MODELS_SAMPLE, ax_dens, ax_trans)
        plt.savefig(fig_prefix+'MX_hubStats.png') #, transparent=True)
        plt.show()
    
    # SMETRICS
    if sm:
        fig = plt.figure(figsize = (4, 4))
        ax = fig.add_subplot(111)
        plot_compare_smetric(MODELS_SAMPLE, ax)
        plt.savefig(fig_prefix+'LAYER_SMetric.png', bbox_inches = "tight")
        plt.show()
    
    if rest:
        #layer degree groups and intersection
        settings = [color_to_model, fig_prefix]
        mxs.plot_compare_layer_intersection(MODELS_SAMPLE, settings)
        mxs.plot_compare_layers_all(MODELS_SAMPLE, settings)
    

