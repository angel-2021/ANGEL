#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
author: Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

analyse a multiplex
'''

import mx_model as mx
import mx_analysis as mxa


mx_model = dict(zip(['BINBALL', 'STARGEN', 'ANGEL'],['binball', 'stargen', 'angel_multiplex']))
for mx_name in ['BINBALL', 'STARGEN', 'ANGEL']:
    # call multiplex creation method
    LAYERS, MX = eval('mx.'+ mx_model[mx_name] +'()')
    print(mx_name, MX.number_of_nodes(), MX.number_of_edges())

        
    """
    PLOTS 
    """
    fig_name_prefix = 'FIG_'+ mx_name+'/fig_'+mx_name+'_ANALYSIS_'
    mxa.setFigName(fig_name_prefix)

    mxa.plot_multiplex(MX, LAYERS, 'FIG_'+ mx_name+'/'+mx_name)    
    
    mxa.plot_analysis_layer_degree(LAYERS)
    mxa.plot_analysis_layer_density(LAYERS)
    mxa.plot_analysis_layer_intersection(LAYERS)
    mxa.plot_analysis_layer_repetition(LAYERS)
    mxa.plot_analysis_layer_repetition_fitting(LAYERS)
    mxa.plot_analysis_layer_sizes(LAYERS)
    mxa.plot_analysis_hubs_degree(LAYERS)


    





    

