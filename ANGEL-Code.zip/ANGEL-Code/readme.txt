*************
All scripts run within an environment with 
python 3.8.11
networkx 2.6.2
matplotlib 3.4.2

With these fixed, you should be able to launch "mx_test" and "mx_test_benchmark" without problems. 
*************


1) Launch "mx_test" to generate a single multiplex per model BINBALL, STARTGEN or ANGEL.
 
mx_test - a small script to create one multiplex of each type (BINBALL, STARTGEN, ANGEL) and then generate the plots with statistics to analyze that multiplex. The plots are stored in the directories FIG_* respectively. There are examples in FIG_ANGEL to get an idea of what the plots display. 

2) Launch "mx_test_benchmark" to generate a benchmark of multiplexes per model

mx_test_benchmark - test script with a comparison of the three models. It will work if only one model is considered (e.g. models=['ANGEL']) and only one sample (nbOfSamples = 1). The plots are saved in the directory FIG_TEST_ALL. There are examples there as well. 
IMPORTANT: to make sure the comparison between the different multiplex models works, they all have to have the same number of nodes. The variable nbOfNodes has to be up to date.

3) All other files in the folder are plugins. All methods implemented there can be used also separately.

mx_model - methods to generate a multiplex of one of the three models BINBALL, STARGEN and ANGEL
mx_analysis - methods to plot statistics for a single multiplex
mx_functions - a library with simple methods used in the above files
mx_plots - plots with a comparison of the three models
mx_stats - auxiliary methods for "mx_plots" 


