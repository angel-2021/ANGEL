#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
author: Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

auxiliary file for ANGEL model
methods for graphs (layers)
'''

import numpy as np
import collections as coll
import networkx as nx
import random
import math


"""
calculate distance between two nodes according to node coordinates 
saved in attributes
@param
    L - a simple graph (layer)
    n, m  - two nodes
@return
    distance between n and m
"""
def dist(L, n, m):
    pos = nx.get_node_attributes(L,'pos')
    (x_n, y_n) = pos[n]
    (x_m, y_m) = pos[m]
    return math.sqrt((x_n-x_m)*(x_n-x_m)+(y_n-y_m)*(y_n-y_m))



"""
layer repetition per node in multiplex
@params:
    M - multiplex, multigraph
    LAYERS - layers in M, simple sub-graphs of M
@return:
    dictionary {node: number of layers containing node}
"""
def layer_rep(M, LAYERS):
    layer_count = {};
    for node in M.nodes:
        layer_count[node] = len([L for L in LAYERS if node in L.nodes])
    return layer_count


"""
set number of hubs for a replicated layer
@params:
    s_metric - s-metric of the original layer, or an equivalent value 
    rate - numberOfNodes/numberOfEdges
@return:
    number of hubs to be assigned to the replicated layer
""" 

def set_nb_of_hubs(s_metrics, rate):
    if s_metrics < 0.5:
        return 0
    
    nb_of_hubs = 1
    if rate < .95: 
        max_number_of_hubs = int((1-rate)*10)
        for _ in range(max_number_of_hubs):
            if random.random() < 1-rate:
                nb_of_hubs += 1
    return nb_of_hubs

"""
hubs in a layer

@param:
    L - layer, a simple graph
    dval - minimum value for smetric to tag a node as a hub
@return:
    hubs - list with nodes tagged as hub 
"""

def hubs_layer(L, dval = 0.3):
    hubs = []                
    d_sm = smetric_per_node(L)
    for node, sm in d_sm.items():
        if sm > dval: hubs.append(node)
    return hubs

"""
hubs in the multiplex, with repetitions
@param:
    LAYERS - list of layers, simple graphs
    repeat - allow repetitions
@return:
    list of nodes (with repetitions or not)
"""

def hubs_multiplex(LAYERS, repeat=True) :
    hubs = []
    for L in LAYERS :
        hubs.extend(hubs_layer(L))
    if repeat:
        return sorted(hubs)
    return list(set(hubs))
    

"""
hub candidates in the preliminary MST on grid
since the structure of the layer is not complete
we take measure s-metric, betweenness and degree centrality

@param:
    L - layer, a simple graph
    val - minimum value for the metrics 
@return:
    hubs - list with so declared hub-nodes 
 
"""

def hubs_MST(L, val = 0.1):
    hubs = []
    betw = nx.betweenness_centrality(L)
    d_sm = smetric_per_node(L)
    for node, sm in d_sm.items():
        if sm > val and betw[node] > val and L.degree[node] > val * (L.number_of_nodes()-1): 
            hubs.append(node)
        
    return hubs



"""
calculate s-metric for each node in a layer L
@param:
    L - layer, a simple graph
@return:
    dictionary {node: s-metric}
"""

def smetric_per_node(L):
    smetric = {}
    n = L.number_of_edges()
    for node in L.nodes:
        dd = 0
        for k in L.nodes:
            if k != node:    
                dd += L.degree[node] * L.degree[k] / (n*n)
        smetric[node] = dd       
    return smetric



"""
compute layer repetition count for one node
@param:
    node - the node
    LAYERS - list of layers, simple graphs
@return:
    count of layer repetition count for node
"""
def layer_repetition_count(node, LAYERS) :
    count = 0
    for L in LAYERS:
        if L.has_node(node) :
            count += 1
    if count < 1 : print('ERROR in angel-functions: node ', node,' layer_repetition_count = 0')
    return count

"""
positions-parameter for networkx draw based on a coordinates saved in node attributes
"""
def set_pos(G):
    coord = nx.get_node_attributes(G, 'pos')
    pos = {}
    for node in G.nodes:
        (x, y) = coord[node]
        pos[node] = [x, y]
    return pos

"""
remove an edge from a graph
"""
def remove_edge(G,i,j):
    if G.has_edge(i,j): 
        G.remove_edge(i,j)
    else: 
        G.remove_edge(j,i)


"""
create a grid for given number of nodes
@param:
    nbOfNodes - number of nodes
@return
    list with nbOfNodes of (x,y) positions
"""
def grid_positions(nbOfNodes):
    grid_size = 3 * (int(math.sqrt(nbOfNodes)))   
    GRID = []                 
    for _ in range(nbOfNodes):
        x, y = random.sample(range(grid_size), 2)
        while (x,y) in GRID:
            x, y = random.sample(range(grid_size), 2)
        GRID.append((x,y))   
    return GRID


"""
add nodes to a layer L with positions if given
otherwise take a random grid position

@params
    L - the layer, a simple graph
    nbOfNodes - number of nodes
    pos - node positions 
"""
def add_nodes_with_pos(L, nbOfNodes, pos):
    # the position of nodes is given
    if len(pos) > 0:
        for k, v in pos.items():
            L.add_node(k, pos=v)
    else:  # select randomly nodes from a grid
        grid_size = 3 * (int(math.sqrt(nbOfNodes)) +1)
        GRID = []
        for n in range(nbOfNodes):
            x, y = random.sample(range(grid_size), 2)
            while (x,y) in GRID:
                x, y = random.sample(range(grid_size), 2)
            GRID.append((x,y))
            L.add_node(n, pos = (x,y))
            
            
            
"""
sort layers by node size
"""
def sort_layers_by_nodesize(LAYERS, reverse=False):
    d = {k: LAYERS[k].number_of_nodes() for k in range(len(LAYERS))}
    d_ord = coll.OrderedDict(sorted(d.items(), key=lambda t: t[1], reverse=reverse))
    N = []
    for k, _ in d_ord.items():
        N.append(LAYERS[k]) 
    return N 

 
"""       
create a multiplex layers
@param:
    list of layers - graph objects - with nodes as subset of a common node set
@return:
    muliplex - a multigraph object on edge sets layers in the list
"""
def create_multiplex(LAYERS):
    MX = nx.MultiGraph()
    for L in LAYERS: 
        MX.add_edges_from(L.edges)
    return MX

"""
KS-TEST

@param:
    list - list with sample to test its distr.
    dict - cumulative histogram values 

"""
def ks_test(sample):
    my_dict = {i:sample.count(i) for i in sample}
    my_dict = dict(sorted(my_dict.items()))
    s = sum(np.array(list(my_dict.values())))
    p_dict = {}
    for i in range(max(list(my_dict.keys()))+1) :
        p_dict[i] = 0
        for k, v in my_dict.items():
            if k >= i:
                p_dict[i] += v
    n_dict = {}
    for k in my_dict.keys():
        n_dict[k] = p_dict[k]/s
    
    return n_dict






























