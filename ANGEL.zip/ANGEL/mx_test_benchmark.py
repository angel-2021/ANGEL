#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
author: Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

plot statistics to a benchmark of multiplexes
'''

import mx_model as mx
import mx_plots as mxp
import mx_stats as mxs

models = ['ANGEL', 'STARGEN', 'BINBALL']
nbOfSamples = 10

nbOfNodes = 417
mxs.setNfOfNode(nbOfNodes)
   
MODELS_SAMPLE = {}
for model in models:
    print('MX', model)
    LAYER_SET = []
    for s in range(nbOfSamples):
        print('iteration:', s+1)
        if model == 'ANGEL':
            LAYER_LIST, M = mx.angel_multiplex()
        elif model == 'STARGEN':
            LAYER_LIST, M = mx.stargen()
        elif model == 'BINBALL':
            LAYER_LIST, M = mx.binball()
        LAYER_SET.append(LAYER_LIST)
    MODELS_SAMPLE[model] = LAYER_SET

fig_name_prefix = 'FIG_TEST_ALL/fig_RES_'
mxp.setFigName(fig_name_prefix)

mxp.plot_stats_all(MODELS_SAMPLE)    