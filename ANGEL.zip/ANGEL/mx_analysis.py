#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
author: Marzena Fügenschuh
Berliner Hochschule für Technik, Berlin Germany
March 2017 - September 2021

plots to analyse a multiplex
'''

"""
*******************************************************************************
*******************************************************************************

ANALYSIS OF A SINGLE MULTIPLEX

*******************************************************************************
*******************************************************************************
"""

import random
import powerlaw
import numpy as np
import networkx as nx
import collections
import statistics as stats
import scipy.stats as sstats
import matplotlib.pyplot as plt  # matplotlib version 3.4.2
from matplotlib import cm

import mx_functions as mf

ref_color = 'red'
model_name = ['BINBALL', 'STARGEN', 'ANGEL']
model_color = ['green', 'orange', 'blue']
color_to_model = dict(zip(model_name, model_color))
fontsize = 12
ref_name = ''  
fig_prefix = ''

def setNames(ref):
    global ref_name
    ref_name = ref
    
    #print('Reference ', ref_name)
    
def setFigName(fpre):
    global fig_prefix
    fig_prefix = fpre
    #print('Figures', fig_prefix)


   
"""
set colors in boxplots
"""
def set_box_color(bp, c1='black', c2 = 'black', c3='black', c4='black'):
    plt.setp(bp['boxes'], color=c1)
    plt.setp(bp['whiskers'], color=c2)
    plt.setp(bp['caps'], color=c3)
    plt.setp(bp['medians'], color=c4)
    plt.setp(bp['fliers'], markeredgecolor=c1, marker='+')
    

    
"""
Number of hubs per layer in multiplex in comparison to reference and s-metrics
@param:
    list of layers - simple graph objects
"""

def plot_analysis_hub_cnt(LS, HUBS_REF):
    
    LAYERS = mf.sort_layers_by_nodesize(LS)
    ratios = []
    hs = []
    hd = []
    hb = []
    for L in LAYERS:
        nN = L.number_of_nodes()
        m = L.number_of_edges()
        ratios.append(nN/m)
        hs.append(len(mf.hubs_layer(L)))
        hd.append(len([n for n in L.nodes if L.degree[n] > 0.3 * nN]))
        hb.append(len([v for v in nx.betweenness_centrality(L).values() if v > 0.3]))
    max_h = max(max(hs), max(hb), max(hd), max(HUBS_REF))
    
    layers_order = sorted(range(len(HUBS_REF)),key=lambda x:HUBS_REF[x])
    
    plt.figure(figsize = (10, 6))
    plt.subplots_adjust(left=None, bottom=0.15, right=None, top=0.85,
            wspace=1.5, hspace=1.5)
    r = 6
    c = 1
    ax1 = plt.subplot2grid((r,c), (0,0), rowspan=4)
    ax2 = plt.subplot2grid((r,c), (4,0), rowspan=2)
    
    x = range(len(LAYERS))
    ax1.plot( x, sorted(HUBS_REF), '-o', label=ref_name, color='r', linewidth=1, alpha=0.7) #markerfacecolor='none'
    y = [hd[i]-.2 for i in layers_order]
    ax1.scatter( x, y, marker='^', label='deg. centr. > 0.3', facecolors='none', edgecolors='g')
    y = [hb[i]-.1 for i in layers_order]
    ax1.scatter( x, y, marker='s', label='betw. centr. > 0.3', facecolors='none', edgecolors='b')
    y = [hs[i]+.1 for i in layers_order]
    ax1.scatter( x, y, marker='d', label='s-metric > 0.3', color='black')
    
    ax1.set_xticks(x)
    labels = ax1.get_xticks().tolist()
    xlabelsnew = []
    for i in range(len(labels)) :
        if i in [0, 9, 19, 29] :
            xlabelsnew.append(str(i+1))
        else:
            xlabelsnew.append(' ')
    ax1.set_xticklabels(xlabelsnew)
    ax1.set_yticks(range(0,max_h+1,1))
    ax1.set_xlabel('layers')
    ax1.set_ylabel('nb of hubs per layer')
    ax1.legend(loc='best')
    
    ratios_order = sorted(range(len(ratios)),key=lambda x:ratios[x])
    ax2.set_axisbelow(True)
    ax2.grid(b=True, which='both', color='0.65',linestyle='-')
    x = [ratios[i] for i in  ratios_order]#sorted(ratios)
    y = [HUBS_REF[i] for i in ratios_order]
    ax2.scatter( x, y, marker='o', label=ref_name, color='r', linewidth=1, alpha=0.7) #markerfacecolor='none'
    ax2.set_xlabel('ratio per layer')
    ax2.set_ylabel('nb of hubs per layer')
    ax2.set_xticks(np.arange(0.2, 1.1, 0.1))
    ax2.set_yticks(range(0,max(HUBS_REF)+1,1))
    ax2.set_ylim(-0.5, 3.5)
    
    plt.savefig(fig_prefix+'hub_finding.png', transparent=True)
    plt.show()
    
    
"""
HUB-SUBNETWORK

degree histogramm on hub subnetwork as simple and multigraph
fitting with configuration model
graph plot
"""
def plot_analysis_hubs_degree(LAYERS):
    hubs = mf.hubs_multiplex(LAYERS, False)
    hubs.sort()
    M = mf.create_multiplex(LAYERS)
    H = M.subgraph(hubs)   
    SH = nx.Graph(H)    # remove multiple edges 
    degree_values_M = sorted([H.degree[k] for k in H.nodes], reverse=True)  
    degree_values_S = sorted([SH.degree[k] for k in SH.nodes], reverse=True)   
    
    # KS-Test and fitted distributions
    #print(degree_values_M)
    exp_param = sstats.uniform.fit(degree_values_M)
    n_dict = mf.ks_test(degree_values_M)
    ks_M = []
    for k, v in n_dict.items():
        ks_M.append(abs(v-(1-sstats.uniform.cdf(k, loc=exp_param[0], scale=exp_param[1]))))
    #print(exp_param[0], exp_param[1], 'KS', max(ks_M), len(degree_values_M))
    x = range(min(degree_values_M),max(degree_values_M))
    cdf_fitted_M = sstats.uniform.cdf(x, loc=exp_param[0], scale=exp_param[1])
    #print('p-value M', ks_alpha(len(degree_values_S), 0.094708), ' S', ks_alpha(len(degree_values_S), 0.11773))
    
    #print(degree_values_S)
    exp_param = sstats.uniform.fit(degree_values_S)
    n_dict = mf.ks_test(degree_values_S)
    ks_S = []
    for k, v in n_dict.items():
        ks_S.append(abs(v-(1-sstats.uniform.cdf(k, loc=exp_param[0], scale=exp_param[1]))))
    #print(exp_param[0], exp_param[1], 'KS', max(ks_S))
    x = range(min(degree_values_S),max(degree_values_S))
    cdf_fitted_S = sstats.uniform.cdf(x, loc=exp_param[0], scale=exp_param[1])

    # fitting the degree distribution with configuration model
    #degrees = np.int_(np.random.uniform(1, len(hubs)*1.2, size= len(hubs)))
    degrees = np.int_(np.random.uniform(1, 75, size= len(hubs)))
    if sum(degrees) % 2 == 1: degrees[0] -= 1 # sum of degrees must be an odd number
    C = nx.configuration_model(degrees)
    E = list(nx.selfloop_edges(C))
    C.remove_edges_from(E)    
    
    fig = plt.figure(figsize=(5, 4.1))
    ax1 = fig.add_subplot(111)
    x = range(min(degree_values_M),max(degree_values_M))
    ax1.plot(x, 1-cdf_fitted_M,'--', color='grey', label='uniform')
    x = range(min(degree_values_S),max(degree_values_S))
    ax1.plot(x, 1-cdf_fitted_S,'--', color='grey')
    ax1.hist( degree_values_S, H.number_of_nodes(), density=True, stacked=True, linewidth=2.,
             color='blue',
             histtype = 'step', cumulative = -1, log=False, label='simple')
    ax1.hist( degree_values_M, H.number_of_nodes(), density=True, stacked=True, linewidth=2.,
             color='orange',
             histtype = 'step', cumulative = -1, log=False, label='multigraph')
    ax1.set_xlabel('k', fontsize=fontsize)
    ax1.set_ylabel('P(degree > k)', fontsize=fontsize)
    ax1.legend(loc='lower left', fontsize=fontsize)
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    ax2 = inset_axes(ax1, width="60%", height="60%", loc=1)
    ax2.axis('off')
    pos = nx.spring_layout(SH)
    nx.draw_networkx_nodes(SH, pos, alpha=0.5, node_color = 'black', node_size=5)
    nx.draw_networkx_edges(SH, pos, width=0.7, alpha=0.4, edge_color = 'grey')
    
    #plt.tight_layout()
    plt.savefig(fig_prefix+'_hub_degree.png', bbox_inches = "tight", transparent=True)
    plt.show()
    
    
"""
LAYER REPETITION COUNT PER NODE 

(all, hubs, nonhubs)
"""

def plot_analysis_layer_repetition(LAYERS):
    
    MX = mf.create_multiplex(LAYERS)
    hubs = mf.hubs_multiplex(LAYERS, False)
    hubs_lrep = sorted([mf.layer_repetition_count(node, LAYERS) for node in hubs], reverse=True) 
    nonhubs = [x for x in MX.nodes if x not in hubs]
    nonhubs_lrep = sorted([mf.layer_repetition_count(node, LAYERS) for node in nonhubs], reverse=True) 
    all_lrep = sorted([mf.layer_repetition_count(node, LAYERS) for node in MX.nodes], reverse=True)    
    
    fig = plt.figure(figsize=(5, 3.8))
    ax = fig.add_subplot(111)
    ax.hist( all_lrep, MX.number_of_nodes(), density=True, stacked=True,
            histtype = 'step', cumulative = -1, linewidth=2, color='orange', label='all nodes')
    ax.hist( nonhubs_lrep, MX.number_of_nodes(), density=True, stacked=True,
                 histtype = 'step', cumulative = -1, linewidth=2, color='g', label='non hubs')
    ax.hist( hubs_lrep, MX.number_of_nodes(), density=True, stacked=True,
            histtype = 'step', cumulative = -1, linewidth=2, color='r', label='hubs')
    
    ax.set_xlabel('k', fontsize=fontsize)
    ax.set_ylabel('P(layer repetition count > k)', fontsize=fontsize)
    ax.set_xticks(range(1,max(all_lrep)+1))
    ax.tick_params(axis='both', which='major', labelsize=fontsize)
    
    ticks = [ i for i in range(1,max(all_lrep)+1,5)]
    #print(ticks)
    
    for index, label in enumerate(ax.xaxis.get_ticklabels()):
        label.set_visible(False)
        if index+1 in ticks:
            label.set_visible(True)

    plt.xlim(0,max(all_lrep) +1)
    plt.grid(b=True, which='both', color='0.65',linestyle='-')
    plt.legend(loc='upper right', fontsize=fontsize) 
    plt.savefig(fig_prefix+'_layer_repetition_hist.png', transparent=True)
    plt.show()


"""
Fitting layer repetition count on non hub nodes
"""
import scipy

def plot_analysis_layer_repetition_fitting(LAYERS):    
    MX = mf.create_multiplex(LAYERS)
    hubs = mf.hubs_multiplex(LAYERS, False)
    nonhubs = [x for x in MX.nodes if x not in hubs]
    layer_rep = sorted([mf.layer_repetition_count(node, LAYERS) for node in nonhubs], reverse=True)    
    
    #distks = scipy.stats.kstest(layer_rep, "expon")

    # plot histogram
    fig = plt.figure(figsize=(5, 4))
    ax1 = fig.add_subplot(111)
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    ax2 = inset_axes(ax1, width="60%", height="60%", loc=1)

    ax1.hist(layer_rep, MX.number_of_nodes(), density=True, stacked=True, 
             histtype = 'step', cumulative = -1, color ='r', linewidth=2.)
   
    # power law fit
    data = np.trim_zeros(np.array(sorted(layer_rep)))
   
    plFit = powerlaw.Fit(data, discrete =True) 
    alpha = plFit.alpha #2.33
    xmin = plFit.xmin - 2 #3.0
    x = np.array(range(1, max(layer_rep)))
    y = pow((x)/xmin, 1-alpha) 
    ax1.plot(x, y, color = 'black', linewidth = 1.)
    #print('PL', alpha, xmin)
    ksdist = powerlaw.power_law_ks_distance(data, plFit.alpha, plFit.xmin, plFit.xmax, discrete=True)
    #print('p-value PL', ks_alpha(len(data), ksdist), ' EXP', ks_alpha(len(data), 0.29602)) # result from R
   
      
    # exponential fit
    exp_param = sstats.expon.fit(layer_rep)
    cdf_fitted= sstats.expon.cdf(x, loc=exp_param[0], scale=exp_param[1])
    ax1.plot(x, 1-cdf_fitted,'--', color='g')
    #print('EXP: ', exp_param)

    # INSET
    # power law fit
    x = np.array(range(1, max(layer_rep)))
    y = pow((x)/xmin, -alpha) * (alpha - 1)/xmin
    ax2.plot(x, y, color = 'black', linewidth= 1., label = 'power law')
    
    # exponential fit
    x = range(1,max(layer_rep))
    pdf_fitted= sstats.expon.pdf(x,loc=exp_param[0],scale=exp_param[1])
    ax2.plot(x,pdf_fitted,'--', color='g', label='exponent.' )

    # REFERENCE
    valuesCnt = collections.Counter(layer_rep)
    _, ref_cnt = zip(*valuesCnt.items())
    ref_cnt = np.array(ref_cnt)/sum(np.array(ref_cnt))
    ax2.hist(layer_rep, max(layer_rep), density=True, stacked=True, 
             histtype = 'step', cumulative=1,
             color ='r', linewidth= 2., label=ref_name) 
        
    # frame axis
    ax1.legend(loc='upper right', fontsize=fontsize)
    ax1.set_xlabel('k', fontsize=fontsize)
    ax1.set_ylabel('P(layer rep. count > k)', fontsize=fontsize)
    ax1.set_ylim(-0.01, 1.01)
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
    
    # inset axes
    ax2.set_ylabel('P(layer rep. count = k)', fontsize=fontsize)
    ax2.set_xlabel('k', fontsize=fontsize)
    ax2.set_ylim(0.001, max(ref_cnt)+ 0.1)
    ax2.set_yscale('log')
    ax2.set_xbound(0, max(layer_rep) +1 )
    ax2.set_xticks(range(1, max(layer_rep) +1,5))
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    ax2.legend(loc='upper right', fontsize=fontsize)
    
    plt.savefig(fig_prefix+'_layer_rep_fit.png', transparent=True)
    plt.show()

"""
Fitting layer repetition count on non hub nodes
"""

def plot_analysis_layer_repetition_fitting_all(LAYERS):    
    MX = mf.create_multiplex(LAYERS)
    layer_rep = sorted([mf.layer_repetition_count(node, LAYERS) for node in MX.nodes], reverse=True)    
    
    # plot histogram
    fig = plt.figure(figsize=(10, 6))
    ax1 = fig.add_subplot(111)
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    ax2 = inset_axes(ax1, width="60%", height="60%", loc=1)

    ax1.hist(layer_rep, MX.number_of_nodes(), density=True, stacked=True, histtype = 'step', 
             cumulative = -1, color ='r', linewidth=2.)
   
    # power law fit
    plFit = powerlaw.Fit(np.trim_zeros(np.array(sorted(layer_rep))), discrete =True) 
    alpha = plFit.alpha #2.33
    xmin = plFit.xmin - 2 #3.0
    x = np.array(range(1, max(layer_rep)))
    y = pow((x)/xmin, 1-alpha) 
    ax1.plot(x, y, color = 'black', linewidth = 1.)
    #print('PL', alpha, xmin)
      
    # exponential fit
    exp_param = sstats.expon.fit(layer_rep)
    cdf_fitted= sstats.expon.cdf(x, loc=exp_param[0], scale=exp_param[1])
    ax1.plot(x, 1-cdf_fitted,'--', color='g')
    #print('EXP: ', exp_param)

    # INSET
    # power law fit
    x = np.array(range(1, max(layer_rep)))
    y = pow((x)/xmin, -alpha) * (alpha - 1)/xmin
    ax2.plot(x, y, color = 'black', linewidth= 1., label = 'power law fit')
    
    # exponential fit
    x = range(1,max(layer_rep))
    pdf_fitted= sstats.expon.pdf(x,loc=exp_param[0],scale=exp_param[1])
    ax2.plot(x,pdf_fitted,'--', color='g', label='exponential fit' )

    # REFERENCE
    valuesCnt = collections.Counter(layer_rep)
    _, ref_cnt = zip(*valuesCnt.items())
    ref_cnt = np.array(ref_cnt)/sum(np.array(ref_cnt))
    ax2.hist(layer_rep, max(layer_rep), density=True, stacked=True, histtype = 'step', 
             color ='r', linewidth= 2., label=ref_name) 
    
    #KS-TEST
    #count repeats per value
    n_dict = mf.ks_test(layer_rep)
    ks_p = []
    ks_e = []
    for k, v in n_dict.items():
        ks_p.append(abs(v-(pow((k)/xmin, 1-alpha))))
        ks_e.append(abs(v-(1-sstats.expon.cdf(k, loc=exp_param[0], scale=exp_param[1]))))
    #print('KS', max(ks_p), max(ks_e))
    
    # frame axes
    ax1.legend(loc='upper right')
    ax1.set_xlabel('k')
    ax1.set_ylabel('P(layer_repetition_count > k)')
    ax1.set_ylim(-0.01, 1.01)
    # inset axes
    ax2.set_ylabel('P(layer_repetition_count = k)')
    ax2.set_xlabel('k')
    ax2.set_ylim(0.001, max(ref_cnt)+ 0.1)
    ax2.set_yscale('log')
    ax2.set_xbound(0, max(layer_rep) +1 )
    ax2.set_xticks(range(1, max(layer_rep) +1,5))
    ax2.legend(loc='upper right')
    
    plt.savefig(fig_prefix+'_layer_rep_fit_all.png', transparent=True)
    plt.show()



"""
BOXPLOT ON NODE DEGREES IN LAYERS

per layer:
boxplots with degrees, pointplots with number of nodes and edges
"""

def plot_analysis_layer_degree(LAYERS):
    LAYERS = mf.sort_layers_by_nodesize(LAYERS)
 
    layer_degree = []
    for L in LAYERS:
        layer_degree.append([L.degree[n] for n in L.nodes()])
    
    plt.figure(figsize = (10, 4))    
   
    x = [n for n in range(1,len(LAYERS)+1)]
    y = [L.number_of_edges() for L in LAYERS]
    plt.plot(x, y, 's', color='black', mfc = 'none', label= 'nb of edges' )
    y = [L.number_of_nodes() for L in LAYERS]
    plt.plot(x, y, 'go', mfc = 'none', label = 'nb of nodes' )
    
    bp = plt.boxplot(layer_degree) #, vert=True, patch_artist=True)
    set_box_color(bp, c1='b', c2='b', c3='b', c4='r')   
    plt.setp(bp['fliers'], markeredgecolor='b', marker='+')  
    plt.xticks(range(1,len(LAYERS)+1))
    plt.yscale('log')
    plt.plot([1],[1], '-', color='b', label='degree boxplot')
    plt.plot([1],[1], '-', color='r', label='degree median')
    #plt.tick_params(axis='both', which='major', labelsize=fontsize)
    plt.legend(loc='upper left') #, fontsize=fontsize)
    plt.savefig(fig_prefix+'_layer_stat_degree.png', transparent=True)
    plt.show()
    
    
    
"""
NODE OVERLAPPING ACROSS LAYERS

boxplot: per layer normalized intersection size (in %) with all other layers
"""

"""
LAYER INTERSECTION

intersection of a layer with another layer 
percentage of common nodes
"""
def get_intersection_data(LAYERS):
    LAYERS = mf.sort_layers_by_nodesize(LAYERS)
    layer_prc = []
    index = []
    for L1 in LAYERS:
        inter_cnt = []
        nset1 = sorted(L1.nodes)
        for L2 in LAYERS :
            if L1 != L2:
                nset2 = sorted(L2.nodes)
                intersect = [x for x in nset1 if x in nset2]
                inter_cnt.append(int(100*(len(intersect)/L1.number_of_nodes())))
        layer_prc.append(inter_cnt)
        index.append(L1.number_of_nodes())
        
    #sort by median
    for _ in range(len(layer_prc)) :
        for j in range(len(layer_prc) - 1):
            if stats.median(layer_prc[j]) > stats.median(layer_prc[j+1]) :
                temp = layer_prc[j]
                layer_prc[j] = layer_prc[j+1]
                layer_prc[j+1] = temp
                val = index[j]
                index[j] = index[j+1]
                index[j+1] = val
    return layer_prc, index



def plot_analysis_layer_intersection(LAYERS):
    layer_prc, _ = get_intersection_data(LAYERS)             
                
    fig = plt.figure(figsize=(5.2, 3))
    ax_inter = fig.add_subplot(111)           
    bp = ax_inter.boxplot(layer_prc, vert=True, patch_artist=True) #, showfliers=False)
    set_box_color(bp, c1='b', c2='b', c3='b', c4='r')
    plt.setp(bp['fliers'], markeredgecolor='b', marker='+')
   
    ax_inter.set_xlabel('layers (sorted by median)', fontsize=14)
    ax_inter.set_ylabel('% of nodes in intersection', fontsize=14, labelpad=-1)
    ax_inter.set_ylim(-2,103)
    ax_inter.tick_params(axis='both', which='major', labelsize=14)
    plt.setp(ax_inter.get_xticklabels(), visible=False)
    plt.setp(ax_inter.get_xticklines(), visible=False)
    plt.savefig(fig_prefix+'_layer_intersection.png', transparent=True)
    plt.show()
    
"""
statistics on density and transitivity in layers
"""
    # plot boxplots with statistics on layers
def plot_analysis_layer_density(LAYERS):
    plt.figure(figsize = (5, 3))
    plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                wspace=4.5, hspace=.2)
    r = 1
    c = 4
    boxplot = []
    data = []
    for i in range(4):
        boxplot.append(plt.subplot2grid((r,c), (0,i), colspan=1))
        liste = []
        data.append(liste)
        
    for L in LAYERS:
        data[0].append(nx.density(L))
        data[1].append(nx.transitivity(L))
        data[2].append(stats.mean([stats.mean(nx.single_source_shortest_path_length(L,j).values()) for j in L.nodes]))
        data[3].append(stats.mean(nx.closeness_centrality(L).values()))
    labels = ['density', 'transitivity', 'avg s-path', 'avg c-centr.']
    for i in range(4):
        bp = boxplot[i].boxplot(data[i], widths=0.4, patch_artist=True, labels=[labels[i]])
        set_box_color(bp, c1='b', c2='b', c3='b', c4='r')   
        plt.setp(bp['fliers'], markeredgecolor='b', marker='+')
        boxplot[i].tick_params(axis='both', which='major', labelsize=14)
        
    plt.savefig(fig_prefix+'_layer_density.png', transparent=True)
    plt.show()


"""
LAYER NODE AND EDGE SIZES AND FITTING
"""
def plot_analysis_layer_sizes(LAYERS):
    nbOfLayers = len(LAYERS)

    fig = plt.figure(figsize=(5, 4.1))
    
    # NODE SIZE AND FIT IN FRAME
    ax1 = fig.add_subplot(111)
    
    N = [L.number_of_nodes() for L in LAYERS] 
    ax1.hist(N, nbOfLayers, density=True, stacked=True,
             histtype = 'step', cumulative = -1, color ='r', linewidth=2.) 
   
    # power law fit with powerlaw library
    plFit = powerlaw.Fit(np.trim_zeros(np.array(sorted(N))), discrete =True)  
    alpha = plFit.alpha 
    xmin = plFit.xmin-6 
    ksdist = powerlaw.power_law_ks_distance(np.trim_zeros(np.array(sorted(N))), plFit.alpha, plFit.xmin, plFit.xmax, discrete=True)
    #print('p-value PL', ks_alpha(len(N), ksdist), ' EXP', ks_alpha(len(N), 0.14335)) # result from R
    
    x = np.array(range(min(N),max(N)))
    y = pow((x)/xmin, 1-alpha)
    ax1.plot(x, y, color = 'black', linewidth = 1)
    #print('N: Power law fit (powerlaw): alpha ', alpha, ' xmin ', xmin)
          
    # exponential fit with scipy
    exp_param = sstats.expon.fit(N)
    cdf_fitted= sstats.expon.cdf(x, loc=exp_param[0], scale=exp_param[1])
    ax1.plot(x, 1-cdf_fitted,'--', color='g', linewidth = 1.5 )
    #print('N exponential fit: ', exp_param)  

    # EDGE SIZE AND FIT IN INSET
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    ax2 = inset_axes(ax1, width='60%', height='60%', loc=1)  # upper right

    E = [L.number_of_edges() for L in LAYERS]
    # power law fit on node size
    plFit = powerlaw.Fit(np.trim_zeros(np.array(sorted(E))), discrete =True) 
    alpha = plFit.alpha 
    xmin = plFit.xmin-15
    ksdist = powerlaw.power_law_ks_distance(np.trim_zeros(np.array(sorted(E))), plFit.alpha, plFit.xmin, plFit.xmax, discrete=True)
    #print('p-value PL', ks_alpha(len(E), ksdist), 'EXP', ks_alpha(len(E), 0.21341)) # result from R
    distks = scipy.stats.kstest(sorted(E), 'expon', N = len(E))
    #print('DATA',  distks)
    #print('E: Power law fit (powerlaw): alpha ', alpha, ' xmin ', xmin)
    
    # exponential fit
    exp_param = sstats.expon.fit(E)
    #print('E exponential fit: ', exp_param)

    # power law fit
    x = np.array(range(min(E),max(E)))
    y = pow((x)/xmin, 1-alpha)
    ax2.plot(x, y, color = 'black', linewidth = 1., label = 'pow.' )
      
    # exponential fit
    cdf_fitted= sstats.expon.cdf(x, loc=exp_param[0], scale=exp_param[1])
    #cdf_fitted= sstats.expon.cdf(x, loc=25, scale=exp_param[1])
    
    ax2.plot(x, 1-cdf_fitted,'--', color='g', label='exp.' )   
    ax2.hist(E, nbOfLayers, density=True, stacked=True, histtype = 'step', 
         cumulative = -1, color ='r', linewidth=2.0, label='EATN') 
    
    # frame axis
    ax1.legend(loc='upper right', fontsize=fontsize)
    ax1.set_xlabel('k', fontsize=fontsize)
    ax1.set_ylabel('P(node count > k)', fontsize=fontsize)
    ax1.set_ybound(lower = 0., upper = 1.05)
    ax1.set_xlim(min(N)-3, max(N)+3)
    ax1.set_xticks(range(min(N), max(N),20))
    ax1.tick_params(axis='both', which='major', labelsize=fontsize)
   
    # inset axes
    ax2.set_ylabel("P(edge count > k)", fontsize=fontsize)
    ax2.set_xlabel('k',fontsize=fontsize)
    ax2.set_ylim(0.0008, 1.1)
    ax2.tick_params(axis='both', which='major', labelsize=fontsize)
    ax2.set_xticks(range(50, max(E),100))
    ax2.set_yscale('log')    
    ax2.legend(loc='upper right', fontsize=fontsize)
    
    
    plt.savefig(fig_prefix+'_layer_size_fit.png', transparent=True)
    plt.show()
    
    
    
   


"""
*****************************************************
PLOT MULTIPLEX AND LAYERS, ACCORDING TO NODE POSITIONS IF GIVEN
****************************************************
"""

"""
plot a multiplex according to given positions
"""

def plot_multiplex_1(M, LAYERS, filename='mx.png'):
    # positions of the nodes
    pos = {}
    node_pos = nx.get_node_attributes(M, 'pos')
    if len(node_pos) > 0:
        for node in M.nodes:
            (x, y) = node_pos[node]
            pos[node] = [x, y]
    else:
        pos = nx.spring_layout(M)     
        
    layer_cnt = mf.layer_rep(M, LAYERS)
    labels = dict((n,str(layer_cnt[n])) for n in M.nodes)
    
    max_degree = max([M.degree[n] for n in M.nodes])
    viridis = cm.get_cmap('Blues', max_degree+1)
    colors = viridis(np.linspace(0, 1, max_degree+1))
    node_color = [colors[M.degree[node]] for node in M.nodes]

    N = nx.Graph(M)
    N.remove_edges_from(M.edges)
    fig = plt.figure(figsize = (16, 16))  
    ax1 = fig.add_subplot(111)
    plt.sca(ax1)
    plt.axis('off')
    nx.draw_networkx(M, pos, labels=labels, font_size= 12, node_size=30, 
                     node_color=node_color, edge_color='grey') 
    plt.savefig(filename)
    plt.show()

    
"""
plot one layer
"""
def plot_layer(L, coords=True, size=8, nb=0):
    
    # encounter positions of the nodes
    if coords:
        pos = mf.set_pos(L)
    else: 
        pos = nx.spring_layout(L)

    fig = plt.figure(figsize = (size,size))  
    ax1 = fig.add_subplot(111)
    plt.sca(ax1)
    plt.axis('off')
    nx.draw_networkx(L, pos, font_size= 1, node_size=10)
    
    n = L.number_of_edges()
    sm = nx.smetric.s_metric(L, normalized=False)/(n*n)
    plt.title( '#N: ' + str(L.number_of_nodes()) + '#E: ' + str(n) 
               + ' #hubs: ' + str(len(mf.hubs_layer(L))) + ' sm: '+ str(round(sm,2)))  
     
    #plt.savefig('PLOTS/L_'+str(nb)+'.png')
    plt.show()
           

"""
two layers to compare
@param: 
    LO, LR - original layer and its replication (simple graph objects)
    LR_nbOfHubs - number of hubs assigned to the replication
    nb - layer id
"""
def plot_compare_layers(LO, LR, LR_nbOfHubs, nb, ref_name):
    fig = plt.figure(figsize = (8, 4))  
    ax1 = fig.add_subplot(121)
    plt.sca(ax1)
    plt.axis('off')
    pos = nx.spring_layout(LO)
    nx.draw_networkx_nodes(LO, pos, width=1.0, alpha=0.8, color = 'r', node_size=5)
    nx.draw_networkx_edges(LO, pos, width=1.0, alpha=0.2, edge_color = 'b')
    plt.title(ref_name+' (nb of hubs: ' + str(len(mf.hubs_layer(LO))) + ')')
    ax2 = fig.add_subplot(122)
    plt.sca(ax2)
    plt.axis('off')
    pos = nx.spring_layout(LR)
    nx.draw_networkx_nodes(LR, pos, width=1.0, alpha=0.8, node_color = 'black', node_size=5)
    nx.draw_networkx_edges(LR, pos, width=1.0, alpha=0.2, edge_color = 'g')
    plt.title('ANGEL (nb of hubs: ' + str(LR_nbOfHubs) + ')')
    plt.savefig('fig_layer'+str(nb)+'.png', transparent=True)
    plt.show()
    
    
"""
TABLES
"""

"""
STATISTICS FOR A HUB CRITERION
"""

"""
hubs count according to betweenness centrality
"""
def hub_test_bc(LAYERS, val):
    val2hub = {}
    for L in LAYERS:
        nb_of_hubs = 0
        d_bc = nx.betweenness_centrality(L)
        for v in d_bc.values():
            if v > val: nb_of_hubs += 1
        val2hub[L] = nb_of_hubs   
    return val2hub

""""
hub count according to smetric value
""" 

def hub_test_sm(LAYERS, val):
    val2hub = {}
    for L in LAYERS:
        nb_of_hubs = 0
        d_sm = mf.smetric_per_node(L)
        for v in d_sm.values():
            if v > val: nb_of_hubs += 1
        val2hub[L] = nb_of_hubs   
    return val2hub

"""
latex table with std on hub counts according to different values of degree centrality,
betweenness centrality and s-metric per node versus given reference counts
@param
    LAYERS - list of simple graphs
    EHUBS - actual hub counts per layer in LAYERS
"""
def table_hub_definition(LAYERS, EHUBS):
    LS = mf.sort_layers_by_nodesize(LAYERS)
    d_eatn = dict(zip(LS, EHUBS))
    
    STD_DC = {}     # degree centrality
    STD_BC = {}     # betweenness centrality
    STD_SM = {}     # s-metric

    for i in range(1,10):
        d_bc = hub_test_bc(LS, i*0.1)
        d_sm = hub_test_sm(LS, i*0.1)
        hub_diff_d = 0
        hub_diff_b = 0
        hub_diff_s = 0
        for L in LS:
            hub_nb = len([n for n in L.nodes() if L.degree(n) > i*0.1 * L.number_of_nodes()])
            hub_diff_d += (hub_nb - d_eatn[L])*(hub_nb - d_eatn[L])
            hub_diff_s += (d_eatn[L] - d_sm[L])*(d_eatn[L] - d_sm[L])
            hub_diff_b += (d_eatn[L] - d_bc[L])*(d_eatn[L] - d_bc[L])
            
        STD_DC[i] = round(hub_diff_d/(len(d_eatn.keys())-1),2) 
        STD_BC[i] = round(hub_diff_b/(len(d_eatn.keys())-1),2) 
        STD_SM[i] = round(hub_diff_s/(len(d_eatn.keys())-1),2)

    for i in range(1,10):
        print(round(i*0.1,1) ,' & ', STD_DC[i], ' & ', STD_BC[i],' & ', STD_SM[i], '\\\\' )    
    
 

"""
latex table with hub statistics in a multiplex
@param 
 LSET - layers of a multiplex, list with simple graphs
"""
def table_layer_hub_stats(LSET):
    LAYERS = mf.sort_layers_by_nodesize(LSET)
    M = mf.create_multiplex(LAYERS)
    mn = M.number_of_nodes()
    lid = 0
    lr = mf.layer_rep(M, LAYERS)
    for L in LAYERS:
        lid += 1
        hubs = mf.hubs_layer(L)
        nn = L.number_of_nodes()
        bet = nx.betweenness_centrality(L)
        sm = mf.smetric_per_node(L)
        if len(hubs) > 0:
            nh = 0
            for h in hubs:
                if nh == 0:
                    print(lid, ' & ', h , ' & ', lr[h], ' & ', round(M.degree[h]/(mn-1), 2), ' & ', round(L.degree[h]/(nn-1), 2), ' & ',
                       round(sm[h],2), '  & ', round(bet[h], 2) , '\\\\')
                else :
                    print(' & ', h , ' & ', lr[h], ' & ', round(M.degree[h]/(mn-1), 2), ' & ', round(L.degree[h]/(nn-1), 2), ' & ',
                       round(sm[h],2), '  & ', round(bet[h], 2) , '\\\\')
                nh += 1 
            #print('\\hline')


"""
plot variance of degree distribution (BINBALL)
"""        
def plot_analysis_degree_var(LAYERS):
    M = mf.create_multiplex(LAYERS)
    var_deg = mf.degree_variance(M, LAYERS)
    
    
    fig = plt.figure(figsize=(5, 4.1))
    
    # NODE SIZE AND FIT IN FRAME
    ax1 = fig.add_subplot(111)
    x = [i+1 for i in range(len(var_deg.keys()))]
    y = [v for v in var_deg.values()]
    ax1.plot(x, y)
    
    plt.show()
    
    
"""
KS 
""" 

def ks_alpha(n, da):
    return 2 * np.exp(-2* n *da *da);
    
    
#STATISTICS ON  THE LAYERS AND THE MULTIPLEX
#latex table
def table_layer_stats(LSET, MX):
    LAYERS = mf.sort_layers_by_nodesize(LSET)
    l_id = 0
    """
    0 - node cnt, 1 - edge cnt, 2 - density, 3 -trans, 4 - av deg, 5 - std deg
    6,7 - av, std stp, 8,9 - av, std clust coeff
    """
    STATS_ALL = [ [] for _ in range(10) ]
    
    for L in LAYERS:
        l_id += 1
        nn = L.number_of_nodes()
        ne = L.number_of_edges()
        den = round(nx.density(L),3)
        tr = round(nx.transitivity(L), 3)
        DEG = [L.degree[n] for n in L.nodes()] 
        mdeg = stats.mean(DEG)
        sdeg = stats.stdev(DEG)
        LCC = max(nx.connected_component_subgraphs(L), key=len)
        mstp = nx.average_shortest_path_length(LCC)
        # all stp lengths
        stp_lens = []
        p = dict(nx.all_pairs_shortest_path_length(LCC))
        for i in L.nodes:
            for j in L.nodes:
                stp_lens.append(p[i][j])
        dstp = stats.stdev(stp_lens)
        mcc = nx.average_clustering(L)
        dcc = stats.stdev(nx.clustering(L).values())

        #print(l_id, ' & ', nn , ' & ', ne, ' & ', den, ' & ', tr, ' & ',
        #               mdeg, '  & ', sdeg, ' & ', mstp, '\\\\')
                
        #print('\\hline')  
        
        STATS_ALL[0].append(nn)
        STATS_ALL[1].append(ne)
        STATS_ALL[2].append(den)
        STATS_ALL[3].append(tr) 
        STATS_ALL[4].append(mdeg)
        STATS_ALL[5].append(sdeg)
        STATS_ALL[6].append(mstp)
        STATS_ALL[7].append(dstp)
        STATS_ALL[8].append(mcc)
        STATS_ALL[9].append(dcc)
    
    for LIST in STATS_ALL:
        print(' & ', round(min(LIST),2), end = '')
    print('\\\\')
    for LIST in STATS_ALL:
        print(' & ', round(max(LIST),2), end = '')
    print('\\\\')
    for LIST in STATS_ALL:
        print(' & ',  round(stats.mean(LIST),2),  end = '')
    print('\\\\')
    for LIST in STATS_ALL:
        print(' & ', round(stats.stdev(LIST),2), end = '')
    print('\\\\')   
    
    # MX stats
    nn = MX.number_of_nodes()
    ne = MX.number_of_edges()
    den = round(nx.density(MX),2)
    MXS = nx.Graph(MX)
    tr = round(nx.transitivity(MXS), 2)
    DEG = [MX.degree[n] for n in MX.nodes()] 
    mdeg = round(stats.mean(DEG),2)
    sdeg = round(stats.stdev(DEG),2)
    MCC = max(nx.connected_component_subgraphs(MX), key=len)
    mstp = round(nx.average_shortest_path_length(MCC),2)
    # all stp lengths for standard deviation
    stp_lens = []
    p = dict(nx.all_pairs_shortest_path_length(MCC))
    for i in MX.nodes:
        for j in MX.nodes:
            stp_lens.append(p[i][j])
    dstp = round(stats.stdev(stp_lens),2)
    
    mcc = round(nx.average_clustering(MXS),2)
    dcc = round(stats.stdev(nx.clustering(MXS).values()),2)

    print(' & ', nn , ' & ', ne, ' & ', den, ' & ', tr, ' & ',
                   mdeg, '  & ', sdeg, ' & ', mstp, ' & ' , dstp, ' & ', mcc, ' & ', dcc, '\\\\')
            
    print('\\hline')  


def plot_multiplex(M, LAYERS, folder):
    # positions of the nodes
    node_pos = nx.get_node_attributes(M, 'pos')
    pos = {}
    node_pos = nx.get_node_attributes(M, 'pos')
    if len(node_pos) > 0:
        for node in M.nodes:
            (x, y) = node_pos[node]
            pos[node] = [x, y]
    else:
        pos = nx.spring_layout(M)  
    
    cm = plt.get_cmap('gist_rainbow')     
    colors = [cm(i//3*3.0/len(LAYERS) ) for i in range(len(LAYERS)) ]
   
    random.shuffle(colors)
    colors= dict(zip(LAYERS, [np.array(c).reshape(1,-1) for c in colors]))
  
    
    plt.figure(figsize = (10, 10)) 
    axm = plt.subplot2grid((1,1), (0,0))  
    #plt.sca(axm)
    plt.axis('off')
    nx.draw_networkx_edges(nx.Graph(M), pos=pos, ax=axm, edge_color='lightgrey', 
                           width=0.5, alpha=0.75)
    
    # node size according to degree
    node_size = dict(zip(M.nodes, [M.degree[node]*5 for node in M.nodes]))
    for L in LAYERS:
        Lnode_size = [node_size[n] for n in L.nodes]
        nx.draw_networkx_nodes(L, ax=axm, pos=pos, node_size=Lnode_size, 
                         node_color=colors[L], alpha=0.5) 
    
    plt.savefig(folder+'_mx.png', dpi=1000)
    plt.show()


    
    